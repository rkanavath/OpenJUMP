/*
 * The Unified Mapping Platform (JUMP) is an extensible, interactive GUI 
 * for visualizing and manipulating spatial features with geometry and attributes.
 *
 * Copyright (C) 2003 Vivid Solutions
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 * For more information, contact:
 *
 * Vivid Solutions
 * Suite #1A
 * 2328 Government Street
 * Victoria BC  V8T 5G5
 * Canada
 *
 * (250)385-6040
 * www.vividsolutions.com
 */

package com.vividsolutions.jump.workbench.model;

import com.vividsolutions.jump.feature.*;
import com.vividsolutions.jump.workbench.ui.renderer.style.*;
import com.vividsolutions.wfs.MapLayer;
import java.awt.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.*;

import javax.swing.JButton;

import com.vividsolutions.jts.geom.Envelope;
import com.vividsolutions.jts.util.Assert;
import com.vividsolutions.jump.util.Blackboard;
import com.vividsolutions.jump.workbench.ui.LayerNameRenderer;
import com.vividsolutions.jump.workbench.ui.LayerViewPanel;
import com.vividsolutions.jump.workbench.ui.renderer.RenderingManager;
import com.vividsolutions.wfs.BoundingBox;
import com.vividsolutions.wfs.MapRequest;
import com.vividsolutions.wfs.WFService;

/**
 * A Layerable that retrieves images from a Web Feature Server.
 */

//TO DO aggiustare la classe per la gestione del gml e non delle img
public class WFSLayer extends Layer implements Cloneable {
	private String format;

	private String layerName;

	private String srs;

	private int alpha = 255;

	private WFService service;

	private String wfsVersion = WFService.WFS_1_0_0;
	/**
	 * Called by Java2XML
	 */
	public WFSLayer() {
	}

	public WFSLayer(LayerManager layerManager, String serverURL, String srs,
			String layerName, String format, String version, LayerViewPanel lp) throws IOException {
		this(layerManager, initializedService(serverURL, version), srs, layerName,
				format, lp);
	}

	private static WFService initializedService(String serverURL, String version)
			throws IOException {
		WFService initializedService = new WFService(serverURL,version);
		initializedService.initialize();
		return initializedService;
	}

	public WFSLayer(LayerManager layerManager, WFService initializedService,
			String srs, String layerName, String format, LayerViewPanel lp) throws IOException {
		this(layerManager, initializedService, srs, layerName, format, initializedService.getVersion(),lp);
	}

	public WFSLayer(LayerManager layerManager, WFService initializedService,
			String srs, String layerName, String format, String version, LayerViewPanel lp)
			throws MalformedURLException {	   
		boolean firingEvents = layerManager.isFiringEvents();
		layerManager.setFiringEvents(false);                                
                Color fillColor = layerManager.generateLayerFillColor();                
		//Color fillColor = Color.GREEN;
		setLayerManager(layerManager);
		setName(layerName);
		setService(initializedService);
		setSRS(srs);                
                this.layerName = layerName;
		setFormat(format);
		MapRequest r;
		try {
			r = createRequest(lp);
			setFeatureCollection(r.getFeatureCollection());
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
		getBlackboard().put(
				RenderingManager.USE_MULTI_RENDERING_THREAD_QUEUE_KEY, true);
		getBlackboard().put(LayerNameRenderer.USE_CLOCK_ANIMATION_KEY, true);
		this.wfsVersion = version;

		try {
			addStyle(new BasicStyle());
			addStyle(new SquareVertexStyle());
			addStyle(new LabelStyle());
		} finally {
			layerManager.setFiringEvents(firingEvents);
		}

		getBasicStyle().setFillColor(fillColor);
		getBasicStyle().setLineColor(defaultLineColor(fillColor));
		getBasicStyle().setAlpha(150);
	
	}
	
	private void setService(WFService service) {
		this.service = service;
		this.serverURL = service.getServerUrl();
	}

	public int getAlpha() {
		return alpha;
	}

	/**
	 * @param alpha
	 *            0-255 (255 is opaque)
	 */
	public void setAlpha(int alpha) {
		this.alpha = alpha;
	}
	
	private BoundingBox toBoundingBox(String srs, Envelope e) {
		return new BoundingBox(srs, e.getMinX(), e.getMinY(), e.getMaxX(), e
				.getMaxY());
	}

	public MapRequest createRequest(LayerViewPanel panel) throws IOException {
		//MapRequest request = getService().createMapRequest();
		// [GC] 07.09.2006
		MapRequest request = getService().createMapRequest(panel);
		// [DR] tentataiv
		MapLayer topLayer = getService().getCapabilities().getTopLayer();
		/*
		for(int i = 0 ; i < topLayer.getSubLayerList().size(); ++i) {
		    System.out.println("Sublayer "+i+" bbox "+
			    topLayer.getSubLayer(i).getBoundingBox().getMaxX());
		}
		ArrayList bbl = topLayer.getAllBoundingBoxList();
		for(int i = 0 ; i < bbl.size(); ++i) {
		    System.out.println(" bbox "+i+": "+
			    ((BoundingBox)bbl.get(i)).getMaxX());
		}*/		
		request.setBoundingBox(
			//scegliere il layer giusto!
			topLayer.getSubLayer(0).getBoundingBox()
		);
		//System.out.println("Got BBox "+request.getBoundingBox());
		/*
		request.setBoundingBox(toBoundingBox(srs, panel.getViewport()
				.getEnvelopeInModelCoordinates()));
		 */
		request.setFormat(format);
		ArrayList layerNames = new ArrayList(1);
		layerNames.add(layerName);
		request.setLayers(layerNames);
		
		return request;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	/*
	public void addLayerName(String layerName) {
		layerNames.add(layerName);
	}

	public List getLayerNames() {
		return Collections.unmodifiableList(layerNames);
	}
	*/
	public void setSRS(String srs) {
		this.srs = srs;
	}

	public String getSRS() {
		return srs;
	}

	public Object clone() throws java.lang.CloneNotSupportedException {
		WFSLayer clone = (WFSLayer) super.clone();
		clone.layerName = this.layerName;

		return clone;
	}
/*
	public void removeAllLayerNames() {
		layerNames.clear();
	}
*/
	private Blackboard blackboard = new Blackboard();

	private String serverURL;

	public Blackboard getBlackboard() {
		return blackboard;
	}

	public WFService getService() throws IOException {
		if (service == null) {
			Assert.isTrue(serverURL != null);
			setService(initializedService(serverURL,wfsVersion));
		}
		return service;
	}

	public String getServerURL() {
		//Called by Java2XML [Jon Aquino 2004-02-23]
		return serverURL;
	}

	public void setServerURL(String serverURL) {
		//Called by Java2XML [Jon Aquino 2004-02-23]
		this.serverURL = serverURL;
	}
    public String getWfsVersion() {
        return wfsVersion;
    }
    public void setWfsVersion(String wfsVersion) {
        this.wfsVersion = wfsVersion;
    }
}