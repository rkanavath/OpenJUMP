package com.vividsolutions.jump.datastore;

/**
 * A simple interface for queries on connections
 */
public interface Query
{
}