package com.vividsolutions.jump.workbench.ui;

import javax.swing.JFrame;


public interface ApplicationExitHandler {
    public void exitApplication( JFrame mainFrame );
}