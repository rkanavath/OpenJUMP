package com.vividsolutions.jump.workbench.model;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.wcs.Capabilities;
import com.vividsolutions.wcs.MapLayer;
import java.awt.Image;
import java.awt.MediaTracker;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;

import com.vividsolutions.jts.geom.Envelope;
import com.vividsolutions.jts.util.Assert;
import com.vividsolutions.jump.util.Blackboard;
import com.vividsolutions.jump.workbench.ui.LayerNameRenderer;
import com.vividsolutions.jump.workbench.ui.LayerViewPanel;
import com.vividsolutions.jump.workbench.ui.renderer.RenderingManager;
import com.vividsolutions.wcs.BoundingBox;
import com.vividsolutions.wcs.MapRequest;
import com.vividsolutions.wcs.WCService;

/**
 * A Layerable that retrieves images from a Web Coverage Server.
 */
public class WCSLayer extends AbstractLayerable implements Cloneable {

    private String format;
    private String tmpImgPath;
    private List layerNames = new ArrayList();
    private String srs;
    private int alpha = 255;
    private WCService service;
    private String wcsVersion = WCService.WCS_1_0_0;

    /**
     * Called by Java2XML
     */
    public WCSLayer() {
    }

    public WCSLayer(LayerManager layerManager, String serverURL, String srs,
            List layerNames, String format, String version) throws IOException {
        this(layerManager, initializedService(serverURL, version), srs, layerNames,
                format);
    }

    private static WCService initializedService(String serverURL, String version)
            throws IOException {
        WCService initializedService = new WCService(serverURL, version);
        initializedService.initialize();
        return initializedService;
    }

    public WCSLayer(LayerManager layerManager, WCService initializedService,
            String srs, List layerNames, String format) throws IOException {
        this(layerManager, initializedService, srs, layerNames, format, initializedService.getVersion());
    }

    public WCSLayer(LayerManager layerManager, WCService initializedService,
            String srs, List layerNames, String format, String version) {
        super((String) layerNames.get(0), layerManager);
        setService(initializedService);
        setSRS(srs);
        this.layerNames = new ArrayList(layerNames);
        setFormat(format);
        getBlackboard().put(
                RenderingManager.USE_MULTI_RENDERING_THREAD_QUEUE_KEY, true);
        getBlackboard().put(LayerNameRenderer.USE_CLOCK_ANIMATION_KEY, true);
        this.wcsVersion = version;
    }

    private void setService(WCService service) {
        this.service = service;
        this.serverURL = service.getServerUrl();
    }

    public int getAlpha() {
        return alpha;
    }

    /**
     * @param alpha
     *            0-255 (255 is opaque)
     */
    public void setAlpha(int alpha) {
        this.alpha = alpha;
    }

    public String getImagePath() {
        return tmpImgPath;
    }

    public Image createImage(LayerViewPanel panel) throws IOException {

        MapRequest req = createRequest(panel);
        Image image = req.getImage();
        tmpImgPath = req.getImagePath();
        MediaTracker mt = new MediaTracker(new JButton());
        mt.addImage(image, 0);

        try {
            mt.waitForID(0);
        } catch (InterruptedException e) {
            Assert.shouldNeverReachHere();
        }

        return image;
    }

    private BoundingBox toBoundingBox(String srs, Envelope e) {
        //System.out.println("toBoundingBox con "+srs+" "+e.getMinX()+" "+e.getMinY());
        return new BoundingBox(srs, e.getMinX(), e.getMinY(), e.getMaxX(), e.getMaxY());
    }

    public MapRequest createRequest(LayerViewPanel panel) throws IOException {
        MapRequest request = getService().createMapRequest();
        //System.out.println("BBOX WCS: "+srs+" "+panel.getViewport().getEnvelopeInModelCoordinates().getMinX());
        request.setBoundingBox(toBoundingBox(srs, panel.getViewport().getEnvelopeInModelCoordinates()));
        request.setFormat(format);
        request.setImageWidth(panel.getWidth());
        request.setImageHeight(panel.getHeight());
        request.setLayers(layerNames);
        request.setTransparent(true);

        return request;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public void addLayerName(String layerName) {
        layerNames.add(layerName);
    }

    public List getLayerNames() {
        return Collections.unmodifiableList(layerNames);
    }

    public void setSRS(String srs) {
        this.srs = srs;
    }

    public String getSRS() {
        return srs;
    }

    public Object clone() throws java.lang.CloneNotSupportedException {
        WCSLayer clone = (WCSLayer) super.clone();
        clone.layerNames = new ArrayList(this.layerNames);

        return clone;
    }

    public void removeAllLayerNames() {
        layerNames.clear();
    }
    private Blackboard blackboard = new Blackboard();
    private String serverURL;

    public Blackboard getBlackboard() {
        return blackboard;
    }

    public WCService getService() throws IOException {
        if (service == null) {
            Assert.isTrue(serverURL != null);
            setService(initializedService(serverURL, wcsVersion));
        }
        return service;
    }

    public String getServerURL() {
        //Called by Java2XML [Jon Aquino 2004-02-23]
        return serverURL;
    }

    public void setServerURL(String serverURL) {
        //Called by Java2XML [Jon Aquino 2004-02-23]
        this.serverURL = serverURL;
    }

    public String getWcsVersion() {
        return wcsVersion;
    }

    public void setWcsVersion(String wcsVersion) {
        this.wcsVersion = wcsVersion;
    }

    //[GC] Gestione full extent
    public Envelope getEnvelope() {
        Envelope env = new Envelope();
        try {
            WCService wcService = getService();
            Capabilities cap = wcService.getCapabilities();
            MapLayer topLayer = cap.getTopLayer();
            ArrayList layerList = topLayer.getLayerList();
            for (Iterator iter = layerList.iterator(); iter.hasNext();) {
                MapLayer layer = (MapLayer) iter.next();
                ArrayList bboxList = layer.getAllBoundingBoxList();
                if (!bboxList.isEmpty()) {
                    BoundingBox bbox = (BoundingBox) bboxList.get(0);
                    Coordinate lower = new Coordinate(bbox.getMinX(), bbox.getMinY());
                    Coordinate upper = new Coordinate(bbox.getMaxX(), bbox.getMaxY());
                    if (env.isNull()) {
                        env.init(lower, upper);
                    } else {
                        Envelope temp = new Envelope(lower, upper);
                        env.expandToInclude(temp);
                    }
                }
            }
        } catch (IOException ioe) {
        }
        //System.out.println(env.toString());
        return env;
    }
}
