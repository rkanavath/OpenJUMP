package com.vividsolutions.jump.workbench.model;

/**
 * Empty implementation of LayerListener.
 */
public class LayerAdapter implements LayerListener {
    public void featuresChanged(FeatureEvent e) {
    }

    public void layerChanged(LayerEvent e) {
    }

    public void categoryChanged(CategoryEvent e) {
    }
}
