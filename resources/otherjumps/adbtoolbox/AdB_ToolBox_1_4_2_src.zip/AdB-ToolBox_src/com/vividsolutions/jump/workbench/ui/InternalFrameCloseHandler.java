package com.vividsolutions.jump.workbench.ui;

import javax.swing.JInternalFrame;



public interface InternalFrameCloseHandler {
    public void close( JInternalFrame internalFrame );
}