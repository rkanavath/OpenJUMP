Color Chooser Plugin 1.3  (29.12.2018)
--------------------------------------
speedup init by delaying popup creation
from 1.40s to 0.01s

Color Chooser Plugin 1.2  (Dicember 2017)
-------------------------------------- 
correct bug on repository

Color Chooser Plugin 1.0  (Dicember 2017)
-------------------------------------- 
Added recent color submenu
Changed icon to Fugue icon set

Color Chooser Plugin 0.9  (November 2017)
-------------------------------------- 
Fix some bugs

Color Chooser Plugin 0.8  (December 2014)
-------------------------------------- 
Added Color picker tool
Rewrite color panel to extend to 255 Autocad Index colors
Tooltips now show correct color in 3 ways: Index color, hexadecimal and decimal RGB

Color Chooser Plugin 0.7  (November 2014)
-------------------------------------- 
The plugin adds an extra attribute ("COLOR") with index color for Autocad compatibility

Color Chooser Plugin 0.6  (April 2013)
-------------------------------------- 
Rearrange color menus

Color Chooser Plugin 0.5  (June 2012)
-------------------------------------- 
Translate Color Chooser in Finnish.
Thanks to Jukka Rahkonen

Color Chooser Plugin 0.4  (June 2012)
------------------------------------- 
Complete Translation of Color Chooser in German, English, Spanish, French and Italian.
Thanks to OpenJUMP Developers and Users Community members

Color Chooser Plugin 0.3  (June 2011)
-------------------------------------- 
Color Chooser plugin for OpenJUMP allows to change color of features in a CAD style way.
This means that users have not to set attributes for features and define a style according to them.
This version of Color Chooser Plugin derives from SkyJUMP (https://sourceforge.net/projects/skyjump/) and was internationalized 
Currently only Italian and English are full internationalized. German, French and Spanish are only partially translated.

NOTES & COPYRIGHT
-------------------------------------- 
Note that this plugin is developed only to test new features for OpenJUMP. 
It is NOT recommended to use it for work or other productive activities as it is still at the first developing stage.
All copyright are reserved to (https://sourceforge.net/projects/skyjump/) under the terms of GNU General Public License 2.
Source Code of ColorChooser PlugIn is embedded into the JAR file or available on
https://sourceforge.net/p/jump-pilot/code/HEAD/tree/plug-ins/Color_chooser/
.

OpenJUMP User Mailing List: http://groups.google.com/group/openjump-users
OpenJUMP Development Mailing List: https://lists.sourceforge.net/lists/listinfo/jump-pilot-devel
OpenJUMP WIKI page: https://sourceforge.net/apps/mediawiki/jump-pilot/index.php?title=Main_Page
-------------------------------------- 

Giuseppe Aruta - GeoArbores Project (https://sourceforge.net/projects/opensit)
Geo Arbores is a project for developing tools and extensions for GIS software and spatial opensource libraries (Kosmo, OpenJUMP and GDAL / OGR).
