package com.geomaticaeambiente.klemgui.exceptions;

/**
 *
 * @author deluca
 */
public class MessageTypes {

    public enum MessageType {
    
        INFO, WARNING, ERROR
    
    }
    
}
