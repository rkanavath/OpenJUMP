package com.geomaticaeambiente.klemgui.ui;

/**
 *
 * @author Geomatica
 */
public abstract class PersonalComponentAbstract {   
       
//    public abstract Object getPersonalComponent();
//    
//    public abstract PersonalComponentType getPersonalComponentType();
//    
//    public enum PersonalComponentType{RECLASS_RASTER, COMBINE_COMBOBOX, 
//    ACTION_OBJECT, PERSONAL_TABLE_OBJ, COMBINE_RASTER};
        
}
