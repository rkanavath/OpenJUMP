package com.geomaticaeambiente.openjump.klem.exceptions;

/**
 *
 * @author AdL
 */
public class NotSpatiallyConsistentGridsException extends  Exception {
    
}
