package com.geomaticaeambiente.openjump.klem;

public class Log {

    public static boolean log = true;

}