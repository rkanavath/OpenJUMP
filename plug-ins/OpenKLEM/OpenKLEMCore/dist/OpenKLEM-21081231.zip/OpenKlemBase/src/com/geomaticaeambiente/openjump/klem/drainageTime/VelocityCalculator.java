package com.geomaticaeambiente.openjump.klem.drainageTime;

/**
 *
 * @author AdL
 */
public interface VelocityCalculator {
    
    public abstract double calcVelocity(double slopeRads);
    
}
