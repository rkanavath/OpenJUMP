package com.geomaticaeambiente.openjump.klem.rastertools.classifiers;

/**
 *
 * @author deluca
 */
public interface ClassAlgo {
    
    public double[] getBreakValues();
    
}
