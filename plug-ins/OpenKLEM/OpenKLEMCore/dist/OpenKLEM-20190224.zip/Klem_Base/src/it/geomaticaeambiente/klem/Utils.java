package it.geomaticaeambiente.klem;

/**
 *
 * @author deluca
 */
public class Utils {
    
    public static final boolean DEBUG = true;
    
    
}
