To test the new Additional result plugin with OpenJUMP and with Sextante:
1) substitute original  default-plugins.xml with the one into this zip file
2) substitute ojsextante_binding_dec2016.jar with  ojsextante_binding_dec2017_alpha.jar 

after launching OJ a new menu item is available on Windows menu: Result viewer.
try to test any Sextante tool which generate an external output (table/chart or text)

Giuseppe Aruta 2017-12-12