/*
 * Library name : fr.michaelm.jump.plugin.topology
 * (C) 2011 Michaël Michaud
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 * For more information, contact:
 *
 * michael.michaud@free.fr
 *
 */
package fr.michaelm.jump.plugin.topology;

import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.index.strtree.STRtree;
import com.vividsolutions.jump.feature.Feature;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

/**
 * Class containing useful static methods related to {@link LinearComponent}s.
 */
public class LinearComponentUtil {
    
    /**
     * Create a spatial index from a colllection of {@link LinearComponent}s.
     */
    public static STRtree getIndex(Collection<Feature> features) {
        STRtree index = new STRtree();
        for (Feature feature : features) {
            for (int i = 0 ; i < feature.getGeometry().getNumGeometries() ; i++) {
                Geometry comp = feature.getGeometry().getGeometryN(i);
                if (comp.getDimension() < 2) {
                    LinearComponent linearComponent = new LinearComponent(feature,i,0);
                    index.insert(linearComponent.getEnvelope(), linearComponent);
                }
                else {
                    Polygon polygon = (Polygon)comp;
                    LinearComponent linearComponent = new LinearComponent(feature,i,0);
                    index.insert(linearComponent.getEnvelope(), linearComponent);
                    for (int j = 0 ; j < polygon.getNumInteriorRing() ; j++) {
                        linearComponent = new LinearComponent(feature,i,j+1);
                        index.insert(linearComponent.getEnvelope(), linearComponent);
                    }
                }
            }
        }
        return index;
    }
    
    //public static Map<Feature,Map<Integer,List<LinearComponent>>> getMap(List<LinearComponent> linearComponents) {
    //    Collections.sort(linearComponents);
    //    Map<Feature,Map<Integer,List<LinearComponent>>> map = 
    //            new HashMap<Feature,Map<Integer,List<LinearComponent>>>();
    //    return map;
    //}
    
}
