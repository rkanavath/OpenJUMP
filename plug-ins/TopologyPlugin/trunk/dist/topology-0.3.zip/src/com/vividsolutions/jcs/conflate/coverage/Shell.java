/*
 * The JCS Conflation Suite (JCS) is a library of Java classes that
 * can be used to build automated or semi-automated conflation solutions.
 *
 * Copyright (C) 2003 Vivid Solutions
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * For more information, contact:
 *
 * Vivid Solutions
 * Suite #1A
 * 2328 Government Street
 * Victoria BC  V8T 5G5
 * Canada
 *
 * (250)385-6040
 * www.vividsolutions.com
 */

package com.vividsolutions.jcs.conflate.coverage;

import java.util.*;
import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jcs.conflate.boundarymatch.SegmentMatcher;

import com.vividsolutions.jcs.qa.FeatureSegment;

/**
 * Models the shell of a polygon which can be matched to other shells
 * and adjusted to contain new vertices.
 */
public class Shell extends GeometryComponent {

    private VertexMap vertexMap;
    private LinearRing ring;
    private boolean isVertex[];
    private Segment[] segments;
    //private Coordinate[] initCoord;
    private Coordinate[] uniqueCoord;
    private Coordinate[] adjustedCoord;

    public Shell(VertexMap vertexMap) {
        this.vertexMap = vertexMap;
    }

    public void initialize(LinearRing ring, Set<Coordinate> adjustableCoords) {
        this.ring = ring;
        uniqueCoord = CoordinateArrays.removeRepeatedPoints(ring.getCoordinates());
        isVertex = new boolean[uniqueCoord.length];
        // create segments
        segments = new Segment[uniqueCoord.length - 1];
        for (int i = 0; i < uniqueCoord.length - 1; i++) {
            createVertex(i, adjustableCoords);
            createVertex(i + 1, adjustableCoords);
        }
    }

   /**
    * Gets a coordinate array which has no repeated points.
    * If there are no repeated points in the input, it is returned.
    * Otherwise a new array is created and returned.
    *
    * @param coords
    * @return the input array if it is adjacent-unique, or a new unique array
    */
  /*
  private static Coordinate[] getUniqueCoordinateArray(Coordinate[] coords)
  {
    if (CoordinateArrays.hasRepeatedPoints(coords)) {
      CoordinateList coordList = new CoordinateList(coords, false);
      return coordList.toCoordinateArray();
    }
    return coords;
  }
  */

   /**
    * Creates a Vertex for vertex i <b>if</b>
    * this is a vertex that might be modified.
    *
    * @param i
    * @param allowableCoords
    */
    private void createVertex(int i, Set<Coordinate> adjustableCoords) {
        Coordinate pt = uniqueCoord[i];
        if (adjustableCoords != null && !adjustableCoords.contains(pt)) return;
        Vertex v0 = vertexMap.get(pt);
        //System.out.println(vertexMap.getVertices());
        //System.out.println(pt);
        //System.out.println(v0);
        v0.addShell(this);
        isVertex[i] = true;
    }

    public Segment getSegment(int i) {
        if (segments[i] == null) segments[i] = createSegment(i);
        return segments[i];
    }

    private Segment createSegment(int i) {
        Vertex v0 = vertexMap.get(uniqueCoord[i]);
        Vertex v1 = vertexMap.get(uniqueCoord[i+1]);
        Segment segment = new Segment(v0, v1, this);
        return segment;
    }

    private boolean isInIndex(SegmentIndex segmentIndex, int i) {
        if (segments[i] == null) {
            return segmentIndex.contains(new FeatureSegment(null, uniqueCoord[i], uniqueCoord[i + 1]));
        }
        return segmentIndex.contains(new FeatureSegment(null, segments[i].getVertex(0).getCoordinate(), segments[i].getVertex(1).getCoordinate()));
    }

    public boolean match(Shell shell, SegmentMatcher segmentMatcher,
                                      SegmentIndex matchedSegmentIndex) {
        // this method might cause the coordinates to change, so make sure they are recomputed
        adjustedCoord = null;
        boolean isAdjusted = false;
        /**
         * Only matched segments are considered for adjustment
         * (Non-matched ones either are already paired,
         * or have no match candidates)
         */
        
        // this is O(n^2), which can be a problem for large polygons
        // (MD - although much better now with the short-circuiting of unmatched segs)
        for (int i = 0; i < segments.length; i++) {
            if (matchedSegmentIndex != null
                && !isInIndex(matchedSegmentIndex, i))
                continue;
            for (int j = 0; j < shell.segments.length; j++) {
                if (matchedSegmentIndex != null
                    && !shell.isInIndex(matchedSegmentIndex, j))
                    continue;
                
                Segment seg0 = getSegment(i);
                Segment seg1 = shell.getSegment(j);
                /**
                 * Inefficient - we already know which segments match
                 * Also, could this be done symmetrically?
                 * eg the segment added to both segments at the same time?
                 */
                LineSegment lineSeg0 = seg0.getLineSegment();
                LineSegment lineSeg1 = seg1.getLineSegment();
                // heuristic to speed up match checking
                if (lineSeg0.distance(lineSeg1) > 2.0 * segmentMatcher.getDistanceTolerance())
                  continue;
                //System.out.println("      Shell.match(): try to match segment " + i + " of shell 1 with segment " + j + " of shell 2");
                boolean isMatch = segmentMatcher.isMatch(lineSeg0, lineSeg1);
                boolean isTopoEqual = lineSeg0.equalsTopo(lineSeg1);
                if (isMatch && !isTopoEqual) {
                    //System.out.println("         ismatch:"+isMatch);
                    isAdjusted |= seg0.addMatchedSegment(seg1, segmentMatcher.getDistanceTolerance());
                }
            }
            
        }
        //System.out.println("         isadjusted:"+isAdjusted);
        return isAdjusted;
    }

    public boolean isAdjusted(double distanceTolerance) {
        computeAdjusted(distanceTolerance);
        boolean isAdjusted = ! CoordinateArrays.equals(uniqueCoord, adjustedCoord);
        return isAdjusted;
    }

    public Coordinate[] getAdjusted(double distanceTolerance) {
        computeAdjusted(distanceTolerance);
        return adjustedCoord;
    }

    private void computeAdjusted(double distanceTolerance) {
        if (adjustedCoord != null) return;
        CoordinateList coordList = new CoordinateList();
        //System.out.println("Shell.computeAdjusted");
        for (int i = 0; i < segments.length; i++) {
            Coordinate pt = getAdjustedCoordinate(i);
            coordList.add(pt, false);
            if (segments[i] != null) {
                coordList.addAll(segments[i].getInsertedCoordinates(), false);
                //System.out.println("  " + segments[i] + " : " + segments[i].getInsertedCoordinates());
            }
        }
        coordList.closeRing();
        CoordinateList noRepeatCoordList = removeRepeatedSegments(coordList);
        noRepeatCoordList = removeMicroLoops(coordList, distanceTolerance);
        adjustedCoord = noRepeatCoordList.toCoordinateArray();
    }

    private Coordinate getAdjustedCoordinate(int i) {
        if (segments[i] != null) {
          return segments[i].getVertex(0).getCoordinate();
        }
        Coordinate pt = uniqueCoord[i];
        if (! vertexMap.contains(pt)) {
            return pt;
        }
        Vertex v = vertexMap.get(pt);
        return v.getCoordinate();
    }

   /**
    * Remove any repeated segments
    * (e.g. a pattern of Coordinates of the form "a-b-a" is converted to "a" )
    *
    * @param coordList
    */
    private CoordinateList removeRepeatedSegments(CoordinateList coordList) {
        //CoordinateList noRepeatCoordList = new CoordinateList();
        //for (int i = 0; i < coordList.size() - 1; i++) {
        //    Coordinate a = coordList.getCoordinate(i);
        //    noRepeatCoordList.add(a, false);
        //    // check for a-b-a pattern
        //    Coordinate b = coordList.getCoordinate(i + 1);
        //    int nexti = i + 2;
        //    if (nexti >= coordList.size()) nexti = 1;
        //    Coordinate a2 = coordList.getCoordinate(nexti);
        //    // if a = a2 we have found a-b-a pattern, so skip b
        //    if (a.equals(a2)) {
        //      i++;
        //    }
        //}
        //noRepeatCoordList.closeRing();
        //return noRepeatCoordList;
        int size = coordList.size();
        for (int i = 0; i < size && size > 4; i++) {
            Coordinate a = coordList.getCoordinate(i%size);
            // check for a-b-a pattern
            Coordinate b = coordList.getCoordinate((i+1)%size);
            Coordinate c = coordList.getCoordinate((i+2)%size);
            if (a.equals(c)) {
                coordList.remove((i+2)%size--);
                coordList.remove((i+1)%size--);
            }
        }
        return coordList;
    }
    
    /**
    * Remove micro-loops
    * (e.g. a pattern of Coordinates of the form "a-b-c-a" with a-b, b-c and c-a
    * smaller than tolerance is converted to "a" )
    *
    * @param coordList
    */
    private CoordinateList removeMicroLoops(CoordinateList coordList, double distanceTolerance) {
        //CoordinateList noRepeatCoordList = new CoordinateList();
        int size = coordList.size();
        for (int i = 0; i < size && size > 5; i++) {
            Coordinate a = coordList.getCoordinate(i%size);
            // check for a-b-c-a pattern
            Coordinate b = coordList.getCoordinate((i+1)%size);
            Coordinate c = coordList.getCoordinate((i+2)%size);
            Coordinate d = coordList.getCoordinate((i+3)%size);
            if (a.equals(d) && a.distance(b)<distanceTolerance &&
                               b.distance(c)<distanceTolerance &&
                               c.distance(d)<distanceTolerance) {
                coordList.remove((i+3)%size--);
                coordList.remove((i+2)%size--);
                coordList.remove((i+1)%size--);
            }
        }
        //noRepeatCoordList.closeRing();
        return coordList;
    }

    public boolean isConflict() {
        for (int i = 0; i < segments.length; i++) {
            if (segments[i] == null) continue;
            if (segments[i].isConflict()) return true;
            if (segments[i].getVertex(0).isConflict()) return true;
            if (segments[i].getVertex(1).isConflict()) return true;
        }
        return false;
    }
}
