/*
 * Library name : fr.michaelm.jump.plugin.topology
 * (C) 2012 Michaël Michaud
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 * For more information, contact:
 *
 * michael.michaud@free.fr
 *
 */

package fr.michaelm.jump.plugin.topology;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;

import com.vividsolutions.jts.algorithm.Angle;
import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.CoordinateArrays;
import com.vividsolutions.jts.geom.CoordinateList;
import com.vividsolutions.jts.geom.Envelope;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryCollection;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineSegment;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.Point;
import com.vividsolutions.jts.geom.Polygon;
import com.vividsolutions.jts.index.strtree.STRtree;
import com.vividsolutions.jts.operation.distance.DistanceOp;
import com.vividsolutions.jts.operation.distance.GeometryLocation;

import com.vividsolutions.jump.feature.*;
import com.vividsolutions.jump.util.StringUtil;
import com.vividsolutions.jump.task.TaskMonitor;
import com.vividsolutions.jump.workbench.model.Layer;
import com.vividsolutions.jump.workbench.model.StandardCategoryNames;
import com.vividsolutions.jump.workbench.plugin.*;
import com.vividsolutions.jump.workbench.ui.ErrorDialog;
import com.vividsolutions.jump.workbench.ui.GUIUtil;
import com.vividsolutions.jump.workbench.ui.MenuNames;
import com.vividsolutions.jump.workbench.ui.MultiInputDialog;

/**
 * PlugIn to project points features on linear network.
 * // TODO make the insert and split options undoable.
 * @author Michael Michaud
 * @version 0.6.0 (2012-09-17)
 */
// History
// 0.6   (2012-09-17) complete rewrite to be able to do multi-projections
// 0.1.0 (2012-12-25) initial version
public class ProjectPointsOnLinesPlugIn extends ThreadedBasePlugIn {
    
    private static String TOPOLOGY;
    private static String PROJECT_POINTS_ON_LINES;
    
    private static String POINT_LAYER;
    private static String POINT_LAYER_TOOLTIP;
    
    private static String LINE_LAYER;
    private static String LINE_LAYER_TOOLTIP;
        
    private static String TOLERANCE;
    private static String TOLERANCE_TOOLTIP;
    
    private static String SNAP;
    private static String SNAP_TOOLTIP;
    
    private static String PROJECT;
    private static String PROJECT_TOOLTIP;
    
    private static String MODIFY_LINE_LAYER;
    private static String MODIFY_LINE_LAYER_TOOLTIP;
    private static String NO_OPERATION;
    private static String INSERT;
    private static String SPLIT;
    
    private static String NEAREST_PROJ_ONLY;
    private static String ALL_PROJ_WITHIN_TOLERANCE;  
        
    private static String CREATE_LINK_LAYER;
    private static String CREATE_LINK_LAYER_TOOLTIP;
    private static String PROJECTED_DISTANCE;
    private static String PROJECTED;
    private static String LINKS;
    
    private static String POINTS_PROCESSED;
    private static String NO_POINT_IN_POINT_LAYER;
    private static String NO_LINE_IN_LINE_LAYER;
    
    Layer point_layer;
    Layer line_layer;
    double tolerance = 10.0;
    boolean snap = false;
    
    boolean project = true;
    String operation;
    boolean insert = false;
    boolean split = false;
    boolean nearest_proj_only = true;
    boolean all_proj_within_tolerance = false;   
    
    boolean create_link_layer = false;
    boolean add_dist_attribute = false;
    
    GeometryFactory gf = new GeometryFactory();
    
    //public String getName() {return "Network topology cleaning PlugIn";}
    
    public void initialize(final PlugInContext context) throws Exception {
        
        TOPOLOGY                   = I18NPlug.getI18N("Topology");
        PROJECT_POINTS_ON_LINES    = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.project-points-on-lines");
                                   
        POINT_LAYER                = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.point-layer");
        POINT_LAYER_TOOLTIP        = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.point-layer-tooltip");
        LINE_LAYER                 = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.line-layer");
        LINE_LAYER_TOOLTIP         = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.line-layer-tooltip");
                                   
        TOLERANCE                  = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.distance-tolerance");
        TOLERANCE_TOOLTIP          = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.distance-tolerance-tooltip");
        SNAP                       = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.vertex-snapping");
        SNAP_TOOLTIP               = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.vertex-snapping-tooltip");
        
        PROJECT                    = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.project");
        PROJECT_TOOLTIP            = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.project-tooltip");
        
        MODIFY_LINE_LAYER          = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.modify-line-layer");
        MODIFY_LINE_LAYER_TOOLTIP  = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.modify-line-layer-tooltip");
        NO_OPERATION               = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.no-operation");
        INSERT                     = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.insert");
        SPLIT                      = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.split");
        
        NEAREST_PROJ_ONLY          = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.nearest-proj-only");
        ALL_PROJ_WITHIN_TOLERANCE  = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.all-proj-within-tolerance");  
        
        CREATE_LINK_LAYER          = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.create-link-layer");
        CREATE_LINK_LAYER_TOOLTIP  = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.create-link-layer-tooltip");
        PROJECTED_DISTANCE         = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.projected-distance");
        PROJECTED                  = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.projected");
        LINKS                      = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.links");
        
        POINTS_PROCESSED           = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.points-processed");
        NO_POINT_IN_POINT_LAYER    = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.no-point-in-point-layer");
        NO_LINE_IN_LINE_LAYER      = I18NPlug.getI18N("ProjectPointsOnLinesPlugIn.no-line-in-line-layer");
        
        context.getFeatureInstaller().addMainMenuItem(
          this, new String[]{MenuNames.PLUGINS, TOPOLOGY},
          PROJECT_POINTS_ON_LINES + "...",
          false, null, new MultiEnableCheck()
          .add(context.getCheckFactory().createTaskWindowMustBeActiveCheck())
          .add(context.getCheckFactory().createAtLeastNLayersMustExistCheck(2)));
    }
    
    public boolean execute(PlugInContext context) {
        
        final MultiInputDialog dialog = new MultiInputDialog(
        context.getWorkbenchFrame(), PROJECT_POINTS_ON_LINES, true);
        // Point layer
        if (point_layer == null || !context.getLayerManager().getLayers().contains(point_layer)) {
            point_layer = context.getCandidateLayer(0);
        }
        final JComboBox jcb_point_layer = dialog.addLayerComboBox(
            POINT_LAYER, point_layer, null, context.getLayerManager());
        
        // Line layer
        if (line_layer == null || !context.getLayerManager().getLayers().contains(line_layer)) {
            int number_of_layers = context.getLayerManager().getLayers().size();
            if (number_of_layers > 1) line_layer = context.getCandidateLayer(1);
            else line_layer = context.getCandidateLayer(0); // should never be the case
        }
        final JComboBox jcb_line_layer = dialog
                .addLayerComboBox(LINE_LAYER, line_layer, null, context.getLayerManager());
        
        // Distance options
        final JTextField jtf_dist_tolerance = dialog
                .addDoubleField(TOLERANCE, tolerance, 12, TOLERANCE_TOOLTIP);
        final JCheckBox jcb_snap = dialog.addCheckBox(SNAP, snap, SNAP_TOOLTIP);
        
        // Output options
        dialog.addSeparator();
        final JCheckBox jcb_project = dialog.addCheckBox(PROJECT, project, PROJECT_TOOLTIP);
        final JComboBox jcb_line_operation = dialog
                .addComboBox(MODIFY_LINE_LAYER, NO_OPERATION,
                             Arrays.asList(new String[]{NO_OPERATION, INSERT, SPLIT}), 
                             MODIFY_LINE_LAYER_TOOLTIP);
        jcb_line_operation.setEnabled(line_layer.isEditable());
        
        final JRadioButton jrb_nearest_proj_only = dialog
                .addRadioButton(NEAREST_PROJ_ONLY, "MULTI", nearest_proj_only, null);
        final JRadioButton jrb_all_proj_within_tolerance = dialog
                .addRadioButton(ALL_PROJ_WITHIN_TOLERANCE, "MULTI", all_proj_within_tolerance, null);
        
        final JCheckBox jcb_create_link_layer = dialog
                .addCheckBox(CREATE_LINK_LAYER, create_link_layer, CREATE_LINK_LAYER_TOOLTIP);

        // Listeners
        jcb_line_layer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                line_layer = dialog.getLayer(LINE_LAYER);
                jcb_line_operation.setEnabled(line_layer.isEditable());
            }
        });
        
        // get parameters
        GUIUtil.centreOnWindow(dialog);
        dialog.setVisible(true);
        if (dialog.wasOKPressed()) {
            point_layer       = dialog.getLayer(POINT_LAYER);
            line_layer        = dialog.getLayer(LINE_LAYER);
            tolerance         = dialog.getDouble(TOLERANCE);
            snap              = dialog.getBoolean(SNAP);
            project           = dialog.getBoolean(PROJECT);
            insert            = jcb_line_operation.getSelectedItem().equals(INSERT);
            split             = jcb_line_operation.getSelectedItem().equals(SPLIT);
            nearest_proj_only = dialog.getBoolean(NEAREST_PROJ_ONLY);
            all_proj_within_tolerance = dialog.getBoolean(ALL_PROJ_WITHIN_TOLERANCE);
            create_link_layer = dialog.getBoolean(CREATE_LINK_LAYER);
            return true;
        }
        else return false;
        
    }
    
    public void run(TaskMonitor monitor, PlugInContext context) throws Exception {
        monitor.allowCancellationRequests();
        monitor.report(PROJECT_POINTS_ON_LINES + "...");
        
        FeatureCollection fc_points = point_layer.getFeatureCollectionWrapper();
        if (!validPointFC(context.getWorkbenchFrame(), fc_points)) return;
        FeatureCollection fc_lines = line_layer.getFeatureCollectionWrapper();
        if (!validLineFC(context.getWorkbenchFrame(), fc_lines)) return;
        
        // Create a spatial index containing all the linear components of fc_lines
        STRtree linearComponentIndex = LinearComponentUtil.getIndex(fc_lines.getFeatures());
        
        FeatureSchema fs = (FeatureSchema)fc_points.getFeatureSchema().clone();
        fs.addAttribute(PROJECTED_DISTANCE, AttributeType.DOUBLE);
        FeatureCollection projected_points = new FeatureDataset(fs);
        FeatureCollection projection_links = new FeatureDataset(fs);

        int count = 0;
        int tot = fc_points.size();
        //if (split) splitMap = new HashMap<Feature,SortedSet<FeatureLineSegment>>();
        Set<LinearComponent> modifiedComponents = new HashSet<LinearComponent>();
        // Main loop processing each point feature one after the other and
        for (Object o : fc_points.getFeatures()) {
            Feature f = (Feature)o;
            if (count++%100==0 || count>=tot) {
                monitor.report(count, tot, POINTS_PROCESSED);
            }
            // adds target linearComponents after processing each point
            modifiedComponents.addAll(projectOnePoint(f, linearComponentIndex, 
                    projected_points, projection_links));
        }
        if (insert && modifiedComponents != null) {
            for (LinearComponent component : modifiedComponents) {
                component.insertNodes();
            }
        }
        if (split && modifiedComponents != null) {
            for (LinearComponent component : modifiedComponents) {
                component.splitAtNodes();
            }
        }
        if (project) {
            context.getLayerManager().addLayer(StandardCategoryNames.RESULT, 
                point_layer.getName() + " - " + PROJECTED, projected_points);
        }
        if (create_link_layer) {
            context.getLayerManager().addLayer(StandardCategoryNames.RESULT, 
                point_layer.getName() + " - " + LINKS, projection_links);
        }
    
    }
    
    /**
     * Clone featureCollection in a new FeatureDataset having the same schema.
     * Features are cloned and their geometry is also cloned.
     */
    //private FeatureCollection cloneFeatureCollection(FeatureCollection featureCollection) {
    //    FeatureDataset dataset = new FeatureDataset(featureCollection.getFeatureSchema());
    //    for (Iterator i = featureCollection.iterator(); i.hasNext();) {
    //        Feature f = (Feature) i.next();
    //        dataset.add((Feature) f.clone(true));
    //    }
    //    return dataset;
    //}
    
    /**
     * Clone featureCollection in a new FeatureDataset having a different schema.
     * Only attributes with the same name are cloned.
     * WARNING : attributes AttributeType is not checked.
     */
    //private FeatureCollection copyFeatureCollection(FeatureCollection featureCollection, FeatureSchema newfs) {
    //    FeatureDataset dataset = new FeatureDataset(newfs);
    //    FeatureSchema oldfs = featureCollection.getFeatureSchema();
    //    for (Iterator i = featureCollection.iterator(); i.hasNext();) {
    //        Feature f = (Feature) i.next();
    //        Feature newf = new BasicFeature(newfs);
    //        for (int j = 0 ; j < oldfs.getAttributeCount() ; j++) {
    //            String attName = oldfs.getAttributeName(j);
    //            if (newfs.hasAttribute(attName)) {
    //                newf.setAttribute(attName, f.getAttribute(j));
    //            }
    //        }
    //        dataset.add(newf);
    //    }
    //    return dataset;
    //}
    
    // Helper method to copy a Feature to a new Feature with a different schema
    private Feature copyFeature(Feature f, FeatureSchema newfs, boolean deep) {
        Feature feature = new BasicFeature(newfs);
        FeatureSchema oldfs = f.getSchema();
        for (int i = 0 ; i < oldfs.getAttributeCount() ; i++) {
            if (i == oldfs.getGeometryIndex() && !deep) continue;
            String attName = oldfs.getAttributeName(i);
            if (newfs.hasAttribute(attName)) {
                feature.setAttribute(attName, f.getAttribute(i));
            }
        }
        return feature;
    }
    
    /**
     * Main method to process one point.
     * @param p the point to process
     * @param index spatial index of LinearComponents
     * @param projectedPoints FeatureCollection containing projected points
     * @param projectionLinks FeatureCollection containing links from source 
     *        points to projected points
     */
    private List<LinearComponent> projectOnePoint(Feature p, STRtree index,
                FeatureCollection projectedPoints, 
                FeatureCollection projectionLinks) throws Exception {
        
        Geometry point = p.getGeometry();
        Envelope env = new Envelope(point.getCoordinate());
        env.expandBy(tolerance);
        List<LinearComponent> lineCandidates = index.query(env);
        
        List<Node> projections = nearest_proj_only ?
            getNearestNode(point, lineCandidates) :
            getNodesWithinTolerance(point, lineCandidates);
        
        //System.out.println(projections);
        
        return projectNodes(p, projections, projectedPoints, projectionLinks);
    }
    
    private List<Node> getNearestNode(Geometry point, List<LinearComponent> candidates) {
        List<Node> projections = new ArrayList<Node>();
        double minDist = Double.POSITIVE_INFINITY;
        LinearComponent targetComponent = null;
        for (LinearComponent component : candidates) {
            DistanceOp op = new DistanceOp(point, component.getGeometry(), 0.0);
            double dist = op.distance();
            if (dist <= tolerance && dist < minDist) {
                Node node = snap ? 
                    new Node(component, op.nearestLocations(), tolerance) :
                    new Node(component, op.nearestLocations());
                node.setUserData(dist);
                minDist = dist;
                if (projections.isEmpty()) projections.add(node);
                else projections.set(0, node);
                targetComponent = component;
            }
        }
        if ((insert || split) && targetComponent != null) {
            targetComponent.addNode(projections.get(0));
        }
        return projections;
    }
    
    private List<Node> getNodesWithinTolerance(Geometry point, List<LinearComponent> candidates) {
        List<Node> projections = new ArrayList<Node>();
        Coordinate c = point.getCoordinate();
        for (LinearComponent component : candidates) {
            Iterator<LineSegment> it = component.getSegmentIterator();
            double minDist = Double.POSITIVE_INFINITY;
            Node node = null;
            int i = 0;
            while (it.hasNext()) {
                LineSegment lineSegment = it.next();
                double d = lineSegment.distance(c);
                if (d < minDist && d <= tolerance) {
                    node = snap ?
                        new Node(component, i, c, tolerance) :
                        new Node(component, i, c);
                    node.setUserData(d);
                    minDist = d;
                }
                if (node != null && lineSegment.p1.distance(c) > tolerance) {
                    projections.add(node);
                    if (insert || split) component.addNode(node);
                    minDist = Double.POSITIVE_INFINITY;
                    node = null;
                }
                i++;
            }
            // To be able to project onto a single point as for getNearestNode
            if (component.getGeometry().getNumPoints() == 1 && 
                component.getGeometry().getCoordinate().distance(c) <= tolerance) {
                node = new Node(component, 0, c);
            }
            if (node != null) {
                projections.add(node);
                if (insert || split) component.addNode(node);
            }
        }
        return projections;
    }
    
    private List<LinearComponent> projectNodes(Feature p, List<Node> projections,
        FeatureCollection projectedPoints, FeatureCollection projectionLinks) {
        List<LinearComponent> modifiedComponents = new ArrayList<LinearComponent>();
        Geometry point = p.getGeometry();
        for (Node node : projections) {
            Feature proj = copyFeature(p, projectedPoints.getFeatureSchema(), false);
            proj.setGeometry(point.getFactory().createPoint(node.getProjection()));
            proj.setAttribute(PROJECTED_DISTANCE, node.getUserData());
            projectedPoints.add(proj);
            if (create_link_layer) {
                Feature link = proj.clone(false);
                link.setGeometry(point.getFactory().createLineString(
                    new Coordinate[]{node.getCoordinate(), node.getProjection()}
                ));
                link.setAttribute(PROJECTED_DISTANCE, node.getUserData());
                projectionLinks.add(link);
            }
            if (insert || split) modifiedComponents.add(node.getLinearComponent());
        }
        return modifiedComponents;
    }
    

    
    //// Project point f on loc
    //private Feature project(Feature f, GeometryLocation loc, double dist, FeatureSchema fs) {
    //    Feature feature = copyFeature(f, fs, false);
    //    feature.setGeometry(gf.createPoint(loc.getCoordinate()));
    //    feature.setAttribute(PROJECTED_DISTANCE, dist);
    //    return feature;
    //}
    //
    //// Ins�rer le point de localisation loc dans l'objet f
    //private void insert(Feature f, GeometryLocation loc) {
    //    Geometry geom = f.getGeometry();
    //    Object userData = addCoordInUserData(geom, loc.getCoordinate());
    //    CoordinateList coordlist = new CoordinateList(geom.getCoordinates());
    //    coordlist.add(loc.getSegmentIndex()+1, loc.getCoordinate(), false);
    //    geom = geom.getFactory().createLineString(coordlist.toCoordinateArray());
    //    geom.setUserData(userData);
    //    f.setGeometry(geom);
    //}
    //
    //// Add coordinate to the coordinate set to be used to split this geometry 
    //private Object addCoordInUserData(Geometry geom, Coordinate coord) {
    //    Object userData = geom.getUserData();
    //    if (split) {
    //        if (userData == null || !(userData instanceof TreeSet)) {
    //            userData = new TreeSet<Coordinate>();
    //        }
    //        ((TreeSet)userData).add(coord);
    //    }
    //    return userData;
    //}
    //
    //// Split geometries of the line collection feature,
    //// using coordinates accumulated in geometry userData
    //private void split(FeatureCollection fc_lines) {
    //    List<Feature> newFeatures = new ArrayList<Feature>();
    //    for (Object o : fc_lines.getFeatures()) {
    //        Feature f = (Feature)o;
    //        Geometry g = f.getGeometry();
    //        if (g.getUserData() != null && (g.getUserData() instanceof TreeSet)) {
    //            TreeSet splitPoints = (TreeSet)g.getUserData();
    //            Coordinate[] cc = g.getCoordinates();
    //            CoordinateList cl = new CoordinateList();
    //            for (int i = 0 ; i < cc.length ; i++) {
    //                cl.add(cc[i], false);
    //                if (cl.size() > 1 && (splitPoints.contains(cc[i]) || (i==cc.length-1))) {
    //                    if (cl.getCoordinate(0).equals(cc[0])) {
    //                        f.setGeometry(g.getFactory().createLineString(cl.toCoordinateArray()));
    //                    } else {
    //                        Feature newFeature = f.clone(false);
    //                        newFeature.setGeometry(g.getFactory().createLineString(cl.toCoordinateArray()));
    //                        newFeatures.add(newFeature);
    //                    }
    //                    if (cc[i].equals(cc[cc.length-1])) break;
    //                    else i--;
    //                    cl = new CoordinateList();
    //                }
    //            }    
    //        }
    //    }
    //    fc_lines.addAll(newFeatures);
    //}
    //
    //// Split feature at each coordinate included in splitPoints
    //// Change the geometry of feature by the first substring
    //// add new features with feature's semantic and new geometries to newFeatures 
    //private void split(Feature feature, TreeSet<Coordinate> splitPoints, List<Feature> newFeatures) {
    //    Coordinate[] cc = feature.getGeometry().getCoordinates();
    //    CoordinateList cl = new CoordinateList();
    //    boolean firstSubstring = true;
    //    for (int i = 0 ; i < cc.length ; i++) {
    //        cl.add(cc[i], false);
    //        if (cl.size() > 1 && (splitPoints.contains(cc[i]) || (i==cc.length-1))) {
    //            if (firstSubstring) {
    //                feature.setGeometry(feature.getGeometry().getFactory()
    //                    .createLineString(cl.toCoordinateArray()));
    //            } else {
    //                newFeatures.add(createNewFeature(feature, cl));
    //            }
    //            if (cc[i].equals(cc[cc.length-1])) break;
    //            else i--;
    //            firstSubstring = false;
    //            cl = new CoordinateList();
    //        }
    //    }    
    //}
    
    //// Returns a Feature with feature semantic and coordList geometry
    //private Feature createNewFeature(Feature feature, CoordinateList coordList) {
    //    Feature newFeature = feature.clone(false);
    //    GeometryFactory fact = feature.getGeometry().getFactory();
    //    newFeature.setGeometry(fact.createLineString(coordList.toCoordinateArray()));
    //    return newFeature;
    //}
    
    private boolean validPointFC(Component comp, FeatureCollection points) {
        boolean valid = false;
        for (Object o : points.getFeatures()) {
            Geometry g = ((Feature)o).getGeometry();
            if (g instanceof Point) return true;
        }
        JOptionPane.showMessageDialog(comp, NO_POINT_IN_POINT_LAYER);
        return false;
    }
    
    private boolean validLineFC(Component comp, FeatureCollection lines) {
        boolean valid = true;
        for (Object o : lines.getFeatures()) {
            Geometry g = ((Feature)o).getGeometry();
            if (g instanceof LineString) return true;
        }
        JOptionPane.showMessageDialog(comp, NO_LINE_IN_LINE_LAYER);
        return false;
    }
    
    ///**
    // * Returns a Map grouping segments by feature.
    // */
    //private Map<Feature,List<FeatureLineSegment>> getFeatureLineSegmentMap(
    //                                  Collection<FeatureLineSegment> segments) {
    //    Map<Feature,List<FeatureLineSegment>> map = new HashMap<Feature,List<FeatureLineSegment>>();
    //    for (FeatureLineSegment segment : segments) {
    //        List<FeatureLineSegment> segmentList = map.get(segment.getFeature());
    //        if (segmentList == null) {
    //            segmentList = new ArrayList<FeatureLineSegment>();
    //            map.put(segment.getFeature(), segmentList);
    //        }
    //        segmentList.add(segment);
    //    }
    //    return map;
    //}
    //
    //private static STRtree getSegmentsIndex(Collection<Feature> features) {
    //    STRtree idx = new STRtree();
    //    for (Feature feature : features) {
    //        insert(feature, feature.getGeometry(), idx);
    //    }
    //    return idx;
    //}
    //
    //private static void insert(Feature f, Geometry g, STRtree idx) {
    //    for (int i = 0 ; i < g.getNumGeometries() ; i++) {
    //        insert(f, g.getGeometryN(i), idx, i);
    //    }
    //}
    //private static void insert(Feature f, Geometry g, STRtree idx, int compIndex) {}
    //private static void insert(Feature f, Polygon g, STRtree idx, int compIndex) {
    //    insert(f, (LineString)g.getExteriorRing(), idx, compIndex, 0);
    //    for (int i = 0 ; i < g.getNumInteriorRing() ; i++) {
    //        insert(f, g.getInteriorRingN(i), idx, compIndex, i+1);
    //    }
    //}
    //private static void insert(Feature f, LineString g, STRtree idx, int compIndex) {
    //    insert(f, g, idx, compIndex, 0);
    //}
    //private static void insert(Feature f, Point g, STRtree idx, int compIndex) {
    //    Coordinate c = g.getCoordinate();
    //    idx.insert(new Envelope(c, c), new FeatureLineSegment(f,compIndex,0,0));
    //}
    //private static void insert(Feature f, LineString g, STRtree idx, int compIndex, int lineIndex) {
    //    Coordinate[] cc = g.getCoordinates();
    //    for (int i = 0 ; i < cc.length-1 ; i++) {
    //        idx.insert(new Envelope(cc[i], cc[i+1]), new FeatureLineSegment(f,compIndex,lineIndex,i));
    //    }
    //}
    //
    //static class Projection {
    //    DistanceOp op;
    //    FeatureLineSegment segment;
    //    Projection(FeatureLineSegment segment, DistanceOp op) {
    //        this.segment = segment;
    //        this.op = op;
    //    }
    //    
    //}
    //
    //private Projection insertNode(Point point, FeatureLineSegment segment, double tol, boolean snap) {
    //    DistanceOp op = new DistanceOp(point, segment.toGeometry(point.getFactory()));
    //    double d = op.distance();
    //    Projection projection = new Projection(segment, op);
    //    //if (d <= tol) segment.insertNode(segment, projection);
    //    return projection;
    //}

}
