/*
 * Library name : fr.michaelm.jump.plugin.topology
 * (C) 2012 Michaël Michaud
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 * For more information, contact:
 *
 * michael.michaud@free.fr
 *
 */
package fr.michaelm.jump.plugin.topology;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.LineSegment;
import com.vividsolutions.jts.operation.distance.GeometryLocation;

/**
 * A Node is a Coordinate located "on" or "near" a {@link LinearComponent} and
 * holding a reference to a segment of this LinearComponent.
 */
public class Node implements Comparable {
    
    private LinearComponent component;
    private int segmentIndex;
    private Coordinate coordinate;
    private Coordinate projection;
    private Object userData;
    double snapTolerance = 0.0;
    
    
    /**
     * Creates a new Node located on or in front of segment with index 
     * segmetIndex.
     * @param component the linear component this node is related to
     * @param segmentIndex index of the segment this node is projected to
     * @param coordinate the coordinate of the original node (before any 
     * projection)
     */
    public Node(LinearComponent component, int segmentIndex, Coordinate coordinate) {
        this(component, segmentIndex, coordinate, 0.0);
    }
    
    
    /**
     * Creates a new Node located on or in front of segment with index 
     * segmetIndex.
     * @param component the linear component this node is related to
     * @param segmentIndex index of the segment this node is projected to
     * @param coordinate the coordinate of the original node (before any 
     * projection)
     * @param snapTolerance defines how the node will be projected onto the 
     * segment (if distance from node to the target segment ends is lesser than 
     * snap tolerance, the node will be projected on the nearest of these ends)
     */
    public Node(LinearComponent component, int segmentIndex, 
                Coordinate coordinate, double snapTolerance) {
        assert component.getGeometry().getNumPoints() > segmentIndex+1;
        this.component = component;
        this.segmentIndex = segmentIndex;
        this.coordinate = coordinate;
        this.snapTolerance = snapTolerance;
    }
   
    
    /**
     * Creates a new Node located on or in front of segment with index 
     * segmetIndex.
     * @param component the linear component this node is related to
     * @param locs locations of the node and its projection as computed by a 
     * DistanceOp operation.
     */
    public Node(LinearComponent component, GeometryLocation[] locs) {
        this(component, locs, 0.0);
    }
    
    
    /**
     * Creates a new Node located on or in front of segment with index 
     * segmetIndex.
     * @param component the linear component this node is related to
     * @param locs locations of the node and its projection as computed by a 
     * DistanceOp operation.
     * @param snapTolerance defines how the node will be projected onto the 
     * segment (if distance from node to the target segment ends is lesser than 
     * snap tolerance, the node will be projected on the nearest of these ends)
     */
    public Node(LinearComponent component, GeometryLocation[] locs, double snapTolerance) {
        assert component.getGeometry().getNumPoints() > locs[1].getSegmentIndex()+1;
        this.component = component;
        this.segmentIndex = locs[1].getSegmentIndex();
        this.coordinate = locs[0].getCoordinate();
        this.snapTolerance = snapTolerance;
        if (snapTolerance == 0.0) projection = locs[1].getCoordinate();
    }
    
    
    public LinearComponent getLinearComponent() {
        return component;
    }
    
    
    public int getSegmentIndex() {
        return segmentIndex;
    }
    
    
    public Coordinate getCoordinate() {
        return coordinate;
    }
    
    
    /**
     * Get the projection of the Node to its LinearComponent. The projection
     * can be either a perpendicular projection or a projection to the nearest
     * node if a non null tolerance is defined for this Node.
     * Projection is computed only once.
     */
    public Coordinate getProjection() {
        if(projection == null) {
            Coordinate[] cc = component.getGeometry().getCoordinates();
            Coordinate ci = cc[segmentIndex];
            Coordinate cj = cc.length > segmentIndex+1 ? cc[segmentIndex+1] : ci;
            Coordinate p = new LineSegment(ci, cj).closestPoint(coordinate);
            if (snapTolerance > 0) {
                double tol2 = snapTolerance * snapTolerance;
                double dp2 = (coordinate.x-p.x)*(coordinate.x-p.x) + (coordinate.y-p.y)*(coordinate.y-p.y);
                double di2 = (coordinate.x-ci.x)*(coordinate.x-ci.x) 
                        + (coordinate.y-ci.y)*(coordinate.y-ci.y);
                double dj2 = (coordinate.x-cj.x)*(coordinate.x-cj.x) 
                        + (coordinate.y-cj.y)*(coordinate.y-cj.y);
                if (di2 < tol2 && di2 <= dj2) this.projection = ci;
                else if (dj2 < tol2 && dj2 < di2) this.projection = cj;
                else this.projection = p;
            } else projection = p;
        } 
        return projection;
    }
    
    
    /**
     * Return this Node's userData.
     */
    public Object getUserData() {
        return userData;
    }
    
    
    /**
     * Set userData associated with this Node.
     */
    public void setUserData(Object data) {
        this.userData = data;
    }
    
    
    public boolean equals(Object o) {
        if (o instanceof Node) {
            Node node = (Node)o;
            return component.equals(node.component) &&
                    segmentIndex == node.segmentIndex &&
                    coordinate == node.coordinate;
        } else return false;
    }
    
    
    public int hashCode() {
        return coordinate.hashCode();
    }
    
    
    /**
     * Compare this Node's projection position along the segment with another
     * Node's projection position in order to be able to sort them along the
     * segment.
     */
    public int compareTo(Object object) {
        if (object instanceof Node) {
            Node node = (Node)object;
            if (component != node.component) return component.compareTo(node.component);
            if (segmentIndex < node.segmentIndex) return -1;
            else if (segmentIndex > node.segmentIndex) return 1;
            else {
                Coordinate c = component.getGeometry().getCoordinates()[segmentIndex];
                return compare(c, projection, node.getProjection());
            }
        } else return 0;
    }

    // Returns -1 if distance |c-c1| is lesser than |c-c2|,
    // 1 if |c-c1| is greater than |c-c2| and 0 if c1 and c2 are at equal 
    // distance from c 
    private int compare(Coordinate c, Coordinate c1, Coordinate c2) {
        double d1 = (c1.x-c.x)*(c1.x-c.x) + (c1.y-c.y)*(c1.y-c.y);
        double d2 = (c2.x-c.x)*(c2.x-c.x) + (c2.y-c.y)*(c2.y-c.y);
        return Double.compare(d1, d2);
    }
    
    
    public String toString() {
        return coordinate.toString() + " (" + component + ")";
    }
    
}
