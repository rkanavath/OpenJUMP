//Geospatial

package org.h2.util.io;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.h2.engine.Session;

public class PostGIS {

	
	public void ImportPostGISTable(Session session, String url,String login, String password, String query) throws SQLException, ClassNotFoundException{
		
		
		Connection conn = session.createConnection(false);
		Statement stat = conn.createStatement();
		
		String jdbcurl = "jdbc:postgresql:"+url;
		
	
		String driver ="org.postgresql.Driver";
		Connection postgisCon = null;

	
		Class.forName(driver); //.newInstance();
				
		postgisCon =DriverManager.getConnection(jdbcurl, login, password);
		
		
		Statement postgisStat = postgisCon.createStatement();
		
		ResultSet postgisRS = postgisStat.executeQuery(query + "LIKE 0");
		
				
		while( postgisRS.next()){
			
			
			
			
		}
		
		
		
		
	}
	
	
}
