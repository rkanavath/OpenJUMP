//Geospatial

package org.h2.util.io;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.StringTokenizer;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

/**
 * 
 * @author Christophe le principe de la classe ReadGML est de parcourir un
 *         fichier GML et de remplir une table de H2 avec les informations
 *         contenues dans le fichier.
 * 
 */
public class ReadGML {
	// Le fichier contenant les donnees a extraire
	protected XMLStreamReader reader;

	// contient le type SQL de la geometry en cours d'extraction. En SQL
	// lineString et
	// linearString sont identiques
	protected String geomTypeSQL;

	// contient le type reel de la geometry en cours d'extraction
	protected String geomRealType;

	// contient le nom de la table dans laquelle on souhaite recuperer les
	// geometry
	protected String tableName;

	// contient le chemin du fichier gml
	protected String gmlFileName;

	// contient le chemin du fichier xsd
	protected String schemaFileName;

	// statement servant a l'envoi des requetes SQL
	protected Statement st;

	// liste des attributs et de leur type
	protected HashMap<String, String> listeAttributes;

	// nom de l'element indiquant une geometry
	protected String geometryDelimiter;

	
	// Hack job of a constructor to get H2Spatial to build see Funciton.java
	public ReadGML(String gmlFileName) {
		this(gmlFileName, "", "", null);
	}
	
	// Le constructeur se charge de creer le XMLStreamReader en faisant appelle
	// a la methode loadAndParseSource. Il cr�er aussi la table de r�cup�ration
	// des
	// geometry avec la m�thode createTableForGeometry
	public ReadGML(String gmlFileName, String schemaFileName, String tableName,
			Connection conn) {
		super();
		this.tableName = new String(tableName);
		this.gmlFileName = new String(gmlFileName);
		this.schemaFileName = new String(schemaFileName);
		this.listeAttributes = new HashMap<String, String>();
		try {

			this.st = conn.createStatement();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * cette methode cree l'objet XMLStreamReader qui sert a parcourir le
	 * fichier gml
	 * 
	 * @param nameFile
	 */
	public void loadGMLFile() {
		// creation du XMLStreamReader
		XMLInputFactory inputFactory = XMLInputFactory.newInstance();
		try {
			this.reader = inputFactory
					.createXMLStreamReader(new java.io.FileInputStream(
							this.gmlFileName));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (XMLStreamException e) {

			e.printStackTrace();
		}
	}

	/**
	 * permet de recuperer les informations sur les attributs contenus dans le
	 * fichier gml (nom et type) en faisant appel a la classe ReadShema
	 * 
	 */
	public void loadAttributes() {
		try {
			ReadSchema schema = new ReadSchema();
			this.listeAttributes = new HashMap<String, String>(schema
					.readSchema(this.schemaFileName));
			this.geometryDelimiter = schema.getGeometryDelimiter();
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * cette methode parcours le fichier gml en faisant : recuperation de la
	 * geometry puis des attributs (il serait tres simple d'inverser cet ordre
	 * si necessaire)
	 * 
	 */
	public void parseGMLFile() {
		try {
			while (this.reader.hasNext()) {
				String geom = new String(extractGeometry());
				System.out.println(geom);
				HashMap<String, String> attributes = new HashMap<String, String>(
						extractAttributes());
				System.out.println(attributes);
				SQLcommand(geom, attributes);
			}
		} catch (XMLStreamException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Cette methode parcour le fichier GML, repere certains mots cles
	 * definissant des geometry particulieres et lance en consequence la
	 * fonction appropriee au type de geometry trouvee
	 * 
	 * @param nameFile
	 * @throws FileNotFoundException
	 * @throws XMLStreamException
	 */
	private String extractGeometry() {
		String result = new String();
		try {
			boolean exitLoop = false;
			while (!exitLoop && this.reader.hasNext()) {
				if (this.reader.getEventType() == XMLStreamReader.START_ELEMENT) {
					this.geomRealType = new String(this.reader.getLocalName());
					String commandeSQL = new String();

					// les geometry ont ete separee en trois famille de geometry
					// :
					// les simpleGeometry(les point, les linestring, les
					// linearRing et les multipoint)
					// les complexGeometry(les polygon, les multiLineString et
					// les multiLinearRing)
					// les veryComplexGeometry(les multipolygon)
					// cette separation a ete faite car la notation est la meme
					// pour chaque famille de geometry
					// seule le nom de la geometry change
					if (this.geomRealType.equalsIgnoreCase("point")
							|| this.geomRealType.equalsIgnoreCase("lineString")
							|| this.geomRealType.equalsIgnoreCase("linearRing")
							|| this.geomRealType.equalsIgnoreCase("multiPoint")) {
						if (this.geomRealType.equalsIgnoreCase("linearRing")) {
							this.geomTypeSQL = new String("lineString");
						} else {
							this.geomTypeSQL = new String(this.geomRealType);
						}
						commandeSQL = new String(
								getSimpleCommandeSQL(getSimpleGeometry()));
						exitLoop = true;
					} else if (this.geomRealType.equalsIgnoreCase("polygon")
							|| this.geomRealType
									.equalsIgnoreCase("multiLineString")
							|| this.geomRealType
									.equalsIgnoreCase("multiLinearRing")) {
						if (this.geomRealType
								.equalsIgnoreCase("multiLinearRing")) {
							this.geomTypeSQL = new String("multiLineString");
						} else {
							this.geomTypeSQL = new String(this.geomRealType);
						}
						commandeSQL = new String(
								getComplexCommandeSQL(getComplexGeometry()));
						exitLoop = true;
					} else if (this.geomRealType
							.equalsIgnoreCase("multiPolygon")) {
						this.geomTypeSQL = new String(this.geomRealType);
						commandeSQL = new String(
								getVeryComplexCommandeSQL(getVeryComplexGeometry()));
						exitLoop = true;
					} else if (this.geomRealType
							.equalsIgnoreCase("geometryCollection")
							|| this.geomRealType
									.equalsIgnoreCase("multiGeometry")) {
						if (this.geomRealType.equalsIgnoreCase("multiGeometry")) {
							this.geomTypeSQL = new String("geometryCollection");
						} else {
							this.geomTypeSQL = new String(this.geomRealType);
						}

						commandeSQL = new String(
								getGeometryCollectionCommandeSQL(getGeometryCollection()));
						exitLoop = true;
					}
					result = new String(commandeSQL);
				}
				this.reader.next();
			}
		} catch (XMLStreamException e) {

			e.printStackTrace();
		}
		return result;
	}

	/**
	 * met en forme les coordonnees d'une geometry simple afin qu'elles puissent
	 * directement �tre utilisees par la fonction GEOMFROMTEXT.Le but est donc
	 * de renvoyer un String sous la forme : (coord1 coord2,coord3 coord4,coord5
	 * coord6 ....). La methode suivante se chargera de rajouter
	 * POINT,LINESTRING ou MULTIPOINT en fonction de la geometry consideree.
	 * 
	 * @param coordinates
	 * @return
	 */
	private String getSimpleCommandeSQL(LinkedList<String> coordinates) {
		String commandeSQL = new String(coordinates.get(0));
		for (int i = 1; i < coordinates.size(); i++) {
			commandeSQL = new String(commandeSQL + "," + coordinates.get(i));
		}
		commandeSQL = new String("(" + commandeSQL + ")");

		return commandeSQL;
	}

	/**
	 * met en forme les coordonnees d'une geometry complex afin qu'elles
	 * puissent directement �tre utilisees par la fonction GEOMFROMTEXT.Le but
	 * est donc de renvoyer un String sous la forme : ((coord1 coord2,coord3
	 * coord4),(coord5 coord6, ....)). La methode suivante se chargera de
	 * rajouter MULTILINESTRING ou POLYGON en fonction de la geometry
	 * consideree.
	 * 
	 * @param coordinates
	 * @return
	 */
	private String getComplexCommandeSQL(
			LinkedList<LinkedList<String>> coordinates) {
		String commandeSQL = new String(
				getSimpleCommandeSQL(coordinates.get(0)));
		for (int i = 1; i < coordinates.size(); i++) {
			commandeSQL = new String(commandeSQL + ","
					+ getSimpleCommandeSQL(coordinates.get(i)));
		}
		commandeSQL = new String("(" + commandeSQL + ")");

		return commandeSQL;
	}

	/**
	 * met en forme les coordonnees d'une geometry veryComplex afin qu'elles
	 * puissent directement �tre utilisees par la fonction GEOMFROMTEXT.Le but
	 * est donc de renvoyer un String sous la forme : (((coord1 coord2,coord3
	 * coord4),(coord5 coord6, coord7 coord8)),((coord9 coord10,coord11
	 * coord12),(coord13 coord14, coord15 coord16)), ...).
	 * 
	 * @param coordinates
	 * @return
	 */
	private String getVeryComplexCommandeSQL(
			LinkedList<LinkedList<LinkedList<String>>> coordinates) {
		String commandeSQL = new String(getComplexCommandeSQL(coordinates
				.get(0)));
		for (int i = 1; i < coordinates.size(); i++) {
			commandeSQL = new String(commandeSQL + ","
					+ getComplexCommandeSQL(coordinates.get(i)));
		}
		commandeSQL = new String("(" + commandeSQL + ")");

		return commandeSQL;

	}

	/**
	 * met en forme les coordonnees d'une collectionGeometry afin qu'elles
	 * puissent directement �tre utilisees par la fonction GEOMFROMTEXT.Le but
	 * est donc de renvoyer un String sous la forme : (LINESTRING(coord1
	 * coord2,coord3 coord4),POINT(coord5 coord6),POLYGON((coord9
	 * coord10,coord11 coord12),(coord13 coord14, coord15 coord16)), ...).
	 * 
	 * @param geometries
	 * @return
	 * @throws XMLStreamException
	 */
	private String getGeometryCollectionCommandeSQL(
			LinkedList<String> geometries) throws XMLStreamException {
		String commandeSQL = new String(geometries.get(0));
		for (int i = 1; i < geometries.size(); i++) {
			commandeSQL = new String(commandeSQL + "," + geometries.get(i));
		}
		commandeSQL = new String("(" + commandeSQL + ")");

		return commandeSQL;
	}

	/**
	 * cette methode permet de recuperer les coordonnees contenues entre les
	 * deux premieres balises <gml:coordinates> et </gml:coordinates>
	 * rencontrees a partie du moment ou cette methode est declenchee et de les
	 * renvoyer sous la forme d'une liste de String.
	 * 
	 * @return
	 * @throws XMLStreamException
	 */
	private LinkedList<String> getSimpleGeometry() throws XMLStreamException {
		LinkedList<String> result = new LinkedList<String>();
		boolean exitLoop = false;
		while (!exitLoop && this.reader.hasNext()) {
			// recherche de la premiere balise <gml:coordinates>
			if (this.reader.getEventType() == XMLStreamReader.START_ELEMENT) {
				if (this.reader.getLocalName().equalsIgnoreCase("coordinates")) {
					// on recupere l'ensemble des coordonn�es
					String data = new String(this.reader.getElementText());
					// on isole les points de la geometry
					StringTokenizer token = new StringTokenizer(data);

					while (token.hasMoreTokens()) {
						// on isole les valeurs numeriques
						String[] value = token.nextToken().split(",");

						String oneCoordinate = new String();
						oneCoordinate = new String(value[0]);
						for (int i = 1; i < value.length; i++) {
							oneCoordinate = new String(oneCoordinate + " "
									+ value[i]);
						}

						// on stocke le resultat sous la forme d'un couple de
						// float separe par un espace
						result.addLast(oneCoordinate);
					}
					exitLoop = true;
				} else {
					this.reader.next();
				}
			} else {
				this.reader.next();
			}
		}
		return result;
	}

	/**
	 * cette methode recupere l'ensemble des elements d'une multiLineString,
	 * multiLinearRing ou d'un poligon et les renvoie sous la forme d'une liste
	 * de liste de String (soit une liste de simpleGeometry) Pour chaque sous
	 * geometry, cette methode fait appelle a la methode getSimpleGeometry
	 * 
	 * @return
	 * @throws XMLStreamException
	 */
	private LinkedList<LinkedList<String>> getComplexGeometry()
			throws XMLStreamException {
		LinkedList<LinkedList<String>> result = new LinkedList<LinkedList<String>>();

		boolean exitLoop = false;
		while (!exitLoop) {
			// on ne sort de la boucle que lorsque la fin de la multiGeometry
			// que l'on veut recuperer est reperer
			if (this.reader.getEventType() == XMLStreamReader.END_ELEMENT) {
				if (this.reader.getLocalName().equalsIgnoreCase(
						"multiLinearRing")
						|| this.reader.getLocalName().equalsIgnoreCase(
								"multiLineString")
						|| this.reader.getLocalName().equalsIgnoreCase(
								"polygon")) {
					exitLoop = true;
				}
			} else if (this.reader.getEventType() == XMLStreamReader.START_ELEMENT) {
				// pour chaque sous element de la multiGeometry, on recupere ses
				// coordonnees grace a la methode getSimpleGeometry
				if (this.reader.getLocalName().equalsIgnoreCase("coordinates")) {
					result.add(getSimpleGeometry());
				}
			}
			this.reader.next();
		}
		return result;
	}

	/**
	 * Cette m�thode fonctionne de la meme maniere que getComplexGeometry, sauf
	 * qu'elle sert � extraire la multiPolygon (soit des multi-multiGeometry).
	 * Il suffit de transposer les remarques precedentes a cette fonction en
	 * augmentant le degre geometrique de 1.
	 * 
	 * @return
	 * @throws XMLStreamException
	 */
	private LinkedList<LinkedList<LinkedList<String>>> getVeryComplexGeometry()
			throws XMLStreamException {
		LinkedList<LinkedList<LinkedList<String>>> result = new LinkedList<LinkedList<LinkedList<String>>>();

		boolean exitLoop = false;
		while (!exitLoop) {

			if (this.reader.getEventType() == XMLStreamReader.END_ELEMENT) {
				if (this.reader.getLocalName().equalsIgnoreCase("multiPolygon")) {
					exitLoop = true;
				}
			} else if (this.reader.getEventType() == XMLStreamReader.START_ELEMENT) {
				if (this.reader.getLocalName().equalsIgnoreCase("coordinates")) {
					result.add(getComplexGeometry());
				}
			}
			this.reader.next();
		}
		return result;
	}

	/**
	 * Permet de recuperer les geometry de type GeometryCollection
	 * 
	 * @return
	 * @throws XMLStreamException
	 */
	private LinkedList<String> getGeometryCollection()
			throws XMLStreamException {
		LinkedList<String> result = new LinkedList<String>();

		boolean exitLoop = false;
		while (!exitLoop) {
			// on ne sort de la boucle que lorsque la fin de la
			// geometryCollection que l'on veut recuperer est reperer
			if (this.reader.getEventType() == XMLStreamReader.END_ELEMENT) {
				if (this.reader.getLocalName().equalsIgnoreCase(
						"geometryCollection")
						|| this.reader.getLocalName().equalsIgnoreCase(
								"multiGeometry")) {
					exitLoop = true;
				}
			} else if (this.reader.getEventType() == XMLStreamReader.START_ELEMENT) {
				// stocke le type de la geometry contenue dans la
				// geometryCollection
				String geomN = new String();
				if (this.reader.getLocalName().equalsIgnoreCase("point")
						|| this.reader.getLocalName().equalsIgnoreCase(
								"lineString")
						|| this.reader.getLocalName().equalsIgnoreCase(
								"linearRing")
						|| this.reader.getLocalName().equalsIgnoreCase(
								"multiPoint")) {
					if (this.reader.getLocalName().equalsIgnoreCase(
							"linearRing")) {
						geomN = new String("lineString");
					} else {
						geomN = new String(this.reader.getLocalName());
					}
					result.addLast(new String(geomN.toUpperCase()
							+ getSimpleCommandeSQL(getSimpleGeometry())));
				} else if (this.reader.getLocalName().equalsIgnoreCase(
						"polygon")
						|| this.reader.getLocalName().equalsIgnoreCase(
								"multiLineString")
						|| this.reader.getLocalName().equalsIgnoreCase(
								"multiLinearRing")) {
					if (this.reader.getLocalName().equalsIgnoreCase(
							"multiLinearRing")) {
						geomN = new String("multiLineString");
					} else {
						geomN = new String(this.reader.getLocalName());
					}
					result.addLast(new String(geomN.toUpperCase()
							+ getComplexCommandeSQL(getComplexGeometry())));
				} else if (this.reader.getLocalName().equalsIgnoreCase(
						"multiPolygon")) {
					geomN = new String(this.reader.getLocalName());
					result
							.addLast(new String(
									geomN.toUpperCase()
											+ getVeryComplexCommandeSQL(getVeryComplexGeometry())));
				}
			}
			this.reader.next();
		}
		return result;
	}

	/**
	 * Cette fonction cree une table avec le nom donne en argument (si ce nom de
	 * table existe deja dans la base, la table existante est droppee). La
	 * fonction cree une colonne pour chaque type de geometry possible : point,
	 * linestring, polygon...
	 * 
	 * @param name
	 */
	public void createTableForGeometry() {
		// drop la table dont le nom est passe en argument si elle existe
		String commandeSQL = new String("DROP TABLE IF EXISTS "
				+ this.tableName);

		// execution de la requete
		try {
			st.executeUpdate(commandeSQL);

			// requete de creation de la nouvelle table
			commandeSQL = new String("CREATE TABLE " + this.tableName
					+ " (geom geometry");
			// la nouvelle table comporte une colonne pour chaque attribut
			// specifie dans le schema
			for (String attributeName : this.listeAttributes.keySet()) {
				if (this.listeAttributes.get(attributeName).equalsIgnoreCase(
						"String")) {
					commandeSQL = new String(commandeSQL + "," + attributeName
							+ " " + "varchar");
				} else {
					commandeSQL = new String(commandeSQL + "," + attributeName
							+ " " + "float");
				}
			}
			commandeSQL = new String(commandeSQL + ");");
			// execution de la requete
			System.out.println(commandeSQL);
			st.executeUpdate(commandeSQL);
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	/**
	 * recupere la valeur des attributs specifie dans le schema
	 * 
	 * @return
	 * @throws XMLStreamException
	 */
	private HashMap<String, String> extractAttributes()
			throws XMLStreamException {
		HashMap<String, String> result = new HashMap<String, String>();

		boolean exitLoop = false;
		while (!exitLoop && this.reader.hasNext()) {
			// on ne sort de la boucle que lorsque l'on atteint le debut d'une
			// nouvelle geometry, signe que la liste des attributs
			// est finie
			if (this.reader.getEventType() == XMLStreamReader.START_ELEMENT) {
				if (this.reader.getLocalName().equalsIgnoreCase(
						this.geometryDelimiter)) {
					exitLoop = true;
				} else {
					for (String attributeName : this.listeAttributes.keySet()) {
						if (this.reader.getLocalName().equalsIgnoreCase(
								attributeName)) {
							result.put(attributeName, this.reader
									.getElementText());
						}
					}
				}
			}
			this.reader.next();
		}
		return result;
	}

	/**
	 * genere et execute la commandeSQL inserant une geometry dans la base
	 * 
	 * @param geom
	 * @param attributes
	 */
	private void SQLcommand(String geom, HashMap<String, String> attributes) {
		String commandeSQL1 = new String(geom);
		// met en forme la partie insertion de la geometry pure
		commandeSQL1 = new String("GEOMFROMTEXT('"
				+ this.geomTypeSQL.toUpperCase() + commandeSQL1 + "',-1)");
		System.out.println(commandeSQL1);

		String commandeSQL2 = new String();
		String commandeSQL3 = new String();

		// genere le morceau de requete SQL permettant d'inserer egalement les
		// valeurs des attributs (dans les
		// bonnes colonnes)
		for (String attributeName : this.listeAttributes.keySet()) {
			if (attributes.containsKey(attributeName)) {
				commandeSQL2 = new String(commandeSQL2 + "," + attributeName);
				if (this.listeAttributes.get(attributeName).equalsIgnoreCase(
						"String")) {
					if (attributes.get(attributeName).equals("")) {
						commandeSQL3 = new String(commandeSQL3 + ",null");
					} else {
						// au passage on supprime les apostrophes et on les
						// remplace par des "_"
						commandeSQL3 = new String(commandeSQL3
								+ ",'"
								+ attributes.get(attributeName).replace("'",
										"_") + "'");
					}
				} else {
					if (attributes.get(attributeName).equals("")) {
						commandeSQL3 = new String(commandeSQL3 + ",null");
					} else {
						commandeSQL3 = new String(commandeSQL3
								+ ","
								+ Double.parseDouble(attributes
										.get(attributeName)));
					}
				}
			}
		}

		// execute la commande SQL : rempli la table
		try {
			st.executeUpdate("INSERT INTO " + this.tableName + " (geom"
					+ commandeSQL2 + ") VALUES (" + commandeSQL1 + commandeSQL3
					+ ")");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}