//Geospatial

package org.h2.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.vividsolutions.jts.geom.Geometry;

import com.vividsolutions.jts.io.ByteOrderValues;
import com.vividsolutions.jts.io.ParseException;
import com.vividsolutions.jts.io.WKBReader;
import com.vividsolutions.jts.io.WKBWriter;
import com.vividsolutions.jts.io.WKTReader;

import org.h2.engine.Session;
import org.h2.expression.Function;
import org.h2.value.Value;

/**
 * 
 * @author Bocher Erwan, Ingénieur de recherche IRSTV
 * 
 * http://www.irstv.cnrs.fr/
 * 
 * Note
 * 
 * Cette extension pour la base de données H2 a été créée entre septembre et
 * novembre 2006 pendant une courte periode de chômage ou le docteur est nulle
 * part :-(
 * 
 * Aujourd'hui en poste à l'IRSTV, H2-spatial s'officialise :-)
 * 
 * http://www.projet-sigle.org
 * 
 * @contact erwan.bocher@ec-nantes.fr
 * @version 1.0
 * @date 13/11/2006
 * @licence CeCILL
 * @see http://www.cecill.info/
 * 
 * Introduction
 * 
 * This class allows to add spatial functions to H2 database. H2 is the free SQL
 * database under Mozilla Public Licence 1.1. See :
 * http://www.h2database.com/html/frame.html and http://www.mozilla.org/MPL.
 * 
 * This class is based on an original method presented by David Blasby and Chris
 * Holmes for Hsql adn Derby databases. See
 * http://docs.codehaus.org/display/GEOS/SpatialDBBox
 * 
 * 
 * 1. Why
 * 
 * In some case we need to use a simple and portable spatial database.
 * 
 * 
 * eSDI (embedded Spatial Data Infrastructure) es un nuevo concepto y solución
 * para construir y administrar una IDE. Se basa en una observación simple. A
 * veces, especialmente en las pequeñas administraciones locales, se necesita de
 * disponer de un dispositivo mas flexible y mas portátil. Esta solución ya
 * existe en partido con la Geodatabase del software ArcGIS. Sin 6embargo su
 * utilización se limita principalmente al almacenamiento de datos o entonces
 * deben comprar extensiones especializadas como ArcSDE. Si el mundo del GIS
 * libre dispone de base de datos espaciales robustos y potentes (PostgreSQL,
 * MySQL) en cambio en muchas situaciones estas herramientas están demasiado
 * completas con relación a las necesidades y a las utilizaciones que se hacen.
 * Por eso, presentaremos un nuevo tipo de base de datos espaciales quien esta
 * basada sobre la base de datos libre en Java H2-Database. Acoplada con el SIG
 * gvSIG, H2-Espacial permite disponer de un primer nivel de IDE totalmente
 * móvil : eSDI.
 * 
 * H2-spatial is build for multiscale SDI.
 * 
 * 
 * 2.Method
 * 
 * Idea is to bind the JTS library with H2 database. See
 * http://jump-project.org/project.php?PID=JTS&SID=OVER
 * 
 * 
 * 
 * The database spatial architecture was definied by David Blasby and Chris
 * Holmes.
 * 
 * Technical architecture (Java for spatial DB) JAVA Spatial Algorthims (JTS) | |
 * GeoSpatialFunctions (java) | | SQLCodegenerator : auto-Generated spatial DB
 * Bindings and SQL CREATE FUNCTION Bindings (java) | | JAVA DB
 * 
 * 
 * 3.Spatial storage
 * 
 * Spatial data are stored in WKb format in a BLOB datatype
 * 
 * 
 * 
 * 4.Database schema
 * 
 * Database schema is basic. A table corresponds to a geographical layer.
 * Geometry is stored in clob data types.
 * 
 * In the futur work, I'd like to implement OGC simple feature SQL
 * specifications. Database schema will be definied by : - a GEOMETRY_COLUMNS
 * table which describes the available feature tables and their Geometry
 * properties, - a SPATIAL_REF_SYS table which describes the coordinate system
 * and transformations for Geometry.
 * 
 * See : Figure 1 - Schema for features tables using predefinied data types in
 * "Implementation Specification for Geographic information - Simple feature
 * access - Part 2: SQL option"
 * 
 * 
 * 5.Technical choices
 * 
 * Database constraints - Easy to use - Easy to move - Easy to customize - Fast -
 * Written in Java - Good documentation - Clear roadmap - Dynamic community -
 * Licence GPL or compatible
 * 
 * Databases tested
 * 
 * Derby : http://db.apache.org/derby/ HSQLDB : http://www.hsqldb.org/ McKoi :
 * http://mckoi.com/database/ H2 database :
 * http://www.h2database.com/html/frame.html
 * 
 * 
 * 6.Installation
 * 
 * Unzip H2-Spatial
 * 
 * Run h2spatial.bat
 * 
 * 
 * 
 * 7.Using
 * 
 * Create a database see H2 documentation.
 * 
 * Create a table like
 * 
 * CREATE TABLE mySpatialTable(gid INT primary key, the_geom geometry);
 * 
 * Populate table
 * 
 * INSERT INTO mySpatialTable VALUES(1, GeomFromText('POINT(12,1)','1')
 * 
 * Where GeomFromText(arg0,arg1)
 * 
 * arg0 = geometry in WKT format arg1 = EPSG code
 * 
 * Load geospatialFunctions files (copy-paste) and execute it.
 * 
 * Test buffer function using :
 * 
 * SELECT buffer(the_geom, 20) FROM mySpatialTable;
 * 
 * Display available functions :
 * 
 * SELECT * FROM INFORMATION_SCHEMA.FUNCTION_ALIASES
 * 
 * 
 * 
 * 8.Work in progress
 * 
 * Create an independant tool to load gml file into H2 spatial. Currently you
 * can use geoSQLBuilder.
 * 
 * Improve spatial queries using spatial indexes.
 * 
 * Add geometry datatype in H2 database. Geometry in eWKB format.
 * 
 * 
 * 
 * 
 * 9.License
 * 
 * Don't forget this library is under CeCILL license see http://www.cecill.info/
 * 
 * 
 * 10. Download
 * 
 * Go to http://r1.bocher.free.fr
 * 
 * 
 * 11. References
 * 
 * http://docs.codehaus.org/display/GEOS/SpatialDBBox H2 database :
 * http://h2database.com PostGIS : http://postgis.refractions.net/ GeoTools :
 * http://geotools.codehaus.org/ JTS :
 * http://www.vividsolutions.com/jts/jtshome.htm Spécifications pour le stockage
 * de la géométrie dans une base de données :
 * http://www.opengeospatial.org/standards/sfs
 * 
 * 
 */

public class GeoSpatialFunctions {

	static WKBReader wkbreader = new WKBReader();

	public static String GeoVersion() {

		return "1.0";

	}

	public static String LastGeoVersion() {

		return "1.0";

	}

	/**
	 * 
	 * @param arg0
	 *            geometry
	 * @param arg1
	 *            SRID
	 * @return
	 * @throws IOException
	 */

	public static byte[] setWKBGeometry(Geometry arg0, int arg1)
			throws IOException {

		Geometry geom = arg0;
		geom.setSRID(arg1);

		WKBWriter wkbWriter = new WKBWriter(2, ByteOrderValues.LITTLE_ENDIAN);

		return wkbWriter.write(geom);

	}

	public static String setWKTGeometry(Geometry arg0, int arg1)
			throws IOException {

		String geomString = arg0.toString();

		String geomWithSRID = "SRID=" + arg1 + ";" + geomString;

		return geomWithSRID;

	}

	/**
	 * This method is used to read a BLOB datatype in a H2 database and
	 * tranformed it into a JTS geometry
	 * 
	 * @param inputStream
	 * @return geometry
	 * @throws IOException
	 * @throws IOException
	 * @throws ParseException
	 * @throws ParseException
	 * @throws ClassNotFoundException 
	 */

	public static Geometry getGeometry(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {

		
		
		if (Class.forName("[B").isInstance(arg0)) {
			System.out.println(arg0.toString());
			System.out.println(((byte[]) arg0).length);
			for(byte item : (byte[]) arg0)
				System.out.printf("%d ", item);
			System.out.println();

			return wkbreader.read((byte[]) arg0);
		}

		else {
			ByteArrayInputStream bais = (ByteArrayInputStream) arg0;
			byte[] bytes = new byte[bais.available()];
			bais.read(bytes, 0, bais.available());
			return wkbreader.read(bytes);
		}

	}

	/**
	 * 
	 * @param geometry
	 *            in WKT
	 * @param srid
	 * @return
	 * @throws ParseException
	 * @throws IOException
	 */

	public static byte[] GeomFromText(String arg0, int arg1)
			throws ParseException, IOException {

		Geometry geom = new WKTReader().read(arg0);

		return setWKBGeometry(geom, arg1);

	}

	/**
	 * 
	 * @param schemaName
	 * @param tableName
	 * @param columnName
	 * @param srid
	 * @param geomType
	 * @param geomDimension
	 * 
	 * Example: SELECT AddGeometryColumn('public', 'roads_geom', 'geom', 423,
	 * 'LINESTRING', 2) See :
	 * http://postgis.refractions.net/docs/ch04.html#id2523246
	 * @throws SQLException
	 */
	public static void AddGeometryColumn(Session session, String schemaName,
			String tableName, String columnName, int srid, String geomType,
			int geomDimension) throws SQLException {

		Connection conn = session.createConnection(false);
		Statement stat = conn.createStatement();

		stat.execute("ALTER TABLE " + tableName + " ADD " + columnName
				+ " geometry;");

		String insertIntoGeometry_columns = "INSERT INTO geometry_columns  VALUES(?,?,?,?,?,?,?);";

		PreparedStatement prep = conn
				.prepareStatement(insertIntoGeometry_columns);
		prep.setString(1, "");
		prep.setString(2, "");
		prep.setString(3, tableName);
		prep.setString(4, columnName);
		prep.setInt(5, srid);
		prep.setString(6, geomType);
		prep.setInt(7, geomDimension);
		prep.execute();

		prep.close();
		stat.close();

	}

	/*
	 * We need also to add SPATIAL_REF_SYS table CREATE TABLE spatial_ref_sys (
	 * srid integer not null primary key, auth_name varchar(256), auth_srid
	 * integer, srtext varchar(2048), proj4text varchar(2048) ); Source :
	 * PostGIS
	 */

	/*
	 * Format transformation
	 */

	public static String ToString(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.toString();
	}

	public static String AseWKT(Object arg0) throws IOException, ParseException, ClassNotFoundException {

		Geometry geom = getGeometry(arg0);

		return geom.toText();
	}

	/*
	 * Geometry properties
	 */

	public static double Length(Object arg0) throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.getLength();
	}

	public static double Area(Object arg0) throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.getArea();
	}

	public static int NumPoints(Object arg0) throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.getNumPoints();
	}

	/*
	 * OGC 05-134 Table 9 : SQL functions on type Geometry
	 * 
	 */

	public static int Dimension(Object arg0) throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.getDimension();
	}

	public static String GeometryType(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.getGeometryType();
	}

	public static String AsText(Object arg0) throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.toText();
	}

	public static byte[] AsBinary(Object arg0) throws IOException,
			ParseException {

		return (byte[]) arg0;
	}

	public static int SRID(Object arg0) throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.getSRID();
	}

	public static boolean IsEmpty(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		;
		return geom.isEmpty();
	}

	public static boolean IsSimple(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.isSimple();
	}

	public static byte[] Boundary(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return setWKBGeometry(geom.getBoundary(), geom.getSRID());

	}

	public static byte[] Envelope(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return setWKBGeometry(geom.getEnvelope(), geom.getSRID());

	}

	/*
	 * OGC 05-134 Table 15 : SQL functions on type GeomCollection
	 * 
	 */

	public static int NumGeometries(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.getNumGeometries();
	}

	public static byte[] GeometryN(Object arg0, int arg1) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return setWKBGeometry(geom.getGeometryN(arg1), geom.getSRID());

	}

	/*
	 * OGC 05-134 Table 18 : SQL functions that test spatial relationships
	 * Spatial predicats
	 */

	public static boolean Equals(Object arg0, Object arg1) {

		return arg0.equals(arg1);
	}

	public static boolean Disjoint(Object arg0,Object arg1)
			throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);
		return geom.disjoint(geom2);
	}

	public static boolean Touches(Object arg0, Object arg1) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);
		return geom.touches(geom2);
	}

	public static boolean Within(Object arg0, Object arg1) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);
		return geom.within(geom2);
	}

	public static boolean Overlaps(Object arg0,Object arg1)
			throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);
		return geom.overlaps(geom2);
	}

	public static boolean Crosses(Object arg0, Object arg1) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);
		return geom.crosses(geom2);
	}

	public static boolean Intersects(Object arg0, Object arg1)
			throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);

		return geom.intersects(geom2);
	}

	public static boolean Contains(Object arg0, Object arg1)
			throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);

		return geom.contains(geom2);
	}

	public static String Relate(Object arg0, Object arg1) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);
		return geom.relate(geom2).toString();
	}

	/*
	 * OGC 05-134 Table 19 : SQL functions for distance relationships
	 * 
	 */

	public static double Distance(Object arg0, Object arg1) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);

		return geom.distance(geom2);
	}

	/*
	 * OGC 05-134 Table 20 : SQL functions for distance relationships Spatial
	 * operators
	 */

	public static byte[] Intersection(Object arg0, Object arg1)
			throws IOException, ParseException, SQLException, ClassNotFoundException {

		Geometry geom = getGeometry(arg0);

		return setWKBGeometry(geom.intersection(getGeometry(arg1)), geom
				.getSRID());

	}

	public static byte[] Difference(Object arg0, Object arg1)
			throws IOException, ParseException, SQLException, ClassNotFoundException {

		Geometry geom = getGeometry(arg0);

		return setWKBGeometry(geom.difference(getGeometry(arg1)), geom
				.getSRID());

	}

	public static byte[] Union(Object arg0, Object arg1) throws IOException,
			ParseException, SQLException, ClassNotFoundException {

		Geometry geom = getGeometry(arg0);

		return setWKBGeometry(geom.union(getGeometry(arg1)), geom.getSRID());

	}

	public static byte[] SymDifference(Object arg0, Object arg1)
			throws IOException, ParseException, SQLException, ClassNotFoundException {

		Geometry geom = getGeometry(arg0);

		return setWKBGeometry(geom.symDifference(getGeometry(arg1)), geom
				.getSRID());

	}

	public static byte[] Buffer(Object arg0, double arg1) throws IOException,
			ParseException, SQLException, ClassNotFoundException {

		Geometry geom = getGeometry(arg0);

		Geometry geomBuffer = geom.buffer(arg1);

		return setWKBGeometry(geomBuffer, geom.getSRID());

	}

	public static byte[] ConvexHull(Object arg0) throws IOException,
			ParseException, SQLException, ClassNotFoundException {

		Geometry geom = getGeometry(arg0);
		Geometry result = geom.convexHull();

		return setWKBGeometry(result, geom.getSRID());

	}

	/*
	 * Continued
	 */

	public static boolean IsWithinDistance(Object arg0, Object arg1, double arg2)
			throws IOException, ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		Geometry geom2 = getGeometry(arg1);
		return geom.isWithinDistance(geom2, arg2);
	}

	public static boolean IsValid(Object arg0) throws IOException,
			ParseException, ClassNotFoundException {
		Geometry geom = getGeometry(arg0);
		return geom.isValid();

	}

	public static String getSpatialTables(Session session) throws SQLException {

		Connection con = session.createConnection(false);
		DatabaseMetaData databaseMeta = con.getMetaData();
		String[] type = { "TABLE", "VIEW" };
		ResultSet tables = databaseMeta.getTables(con.getCatalog(), null, "%",
				type);
		String tableName;

		List<String> spatialTableName = new ArrayList<String>();

		while (tables.next()) {
			tableName = tables.getString("TABLE_NAME");

			String query = "select * from " + tableName;
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int nbCols = rsmd.getColumnCount();

			String typeSQL;
			for (int i = 1; i <= nbCols; i++) {
				typeSQL = rsmd.getColumnTypeName(i);

				if (typeSQL.equals("GEOMETRY")) {
					spatialTableName.add(tableName);

				} else {

				}
			}

		}
		return spatialTableName.toString();

	}

}
