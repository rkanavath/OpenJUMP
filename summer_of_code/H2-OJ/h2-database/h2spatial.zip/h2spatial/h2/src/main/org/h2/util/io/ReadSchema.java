//Geospatial

package org.h2.util.io;

import java.io.FileNotFoundException;
import java.util.HashMap;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class ReadSchema {
	// attribut indiquant le nom du delimiteur de geometry dans la schema. Ex :
	// en generale la balise
	// <cit:the_geom> annonce une nouvelle geometry. Ici notre attribut vaudra
	// donc 'the_geom'
	private String geometryDelimiter = null;

	public ReadSchema() {
		this.geometryDelimiter = new String();
	}

	public String getGeometryDelimiter() {
		return geometryDelimiter;
	}

	/**
	 * parcours le schema donne jusqu'a trouver la balise sequence qui indique
	 * le debut de l'enonciation des attributs contenus dans le fichier gml
	 * 
	 * @param nameFile
	 * @return
	 * @throws XMLStreamException
	 */
	public HashMap<String, String> readSchema(String nameFile)
			throws XMLStreamException {
		HashMap<String, String> listeAttributes = new HashMap<String, String>();

		// creation du XMLStreamReader
		XMLInputFactory inputFactory = XMLInputFactory.newInstance();
		try {
			XMLStreamReader reader = inputFactory
					.createXMLStreamReader(new java.io.FileInputStream(nameFile));

			boolean exitLoop = false;
			while (!exitLoop && reader.hasNext()) {
				// recherche de la balise sequence
				if (reader.getEventType() == XMLStreamReader.START_ELEMENT) {
					if (reader.getLocalName().equalsIgnoreCase("sequence")) {
						// on recupere le nom des attributs
						listeAttributes = new HashMap<String, String>(
								extractAttributes(reader));
						exitLoop = true;
					}
				}
				reader.next();
			}
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (XMLStreamException e) {

			e.printStackTrace();
		}
		return listeAttributes;
	}

	/**
	 * (une fois la balise sequence atteinte) recupere le nom et le type de
	 * chaque attribut contenu dans le fichier gml
	 * 
	 * @param reader
	 * @return
	 * @throws XMLStreamException
	 */
	public HashMap<String, String> extractAttributes(XMLStreamReader reader)
			throws XMLStreamException {
		HashMap<String, String> listeAttributes = new HashMap<String, String>();
		boolean exitLoop = false;
		while (!exitLoop && reader.hasNext()) {
			// recherche de la balise sequence
			if (reader.getEventType() == XMLStreamReader.END_ELEMENT) {
				if (reader.getLocalName().equalsIgnoreCase("sequence")) {
					// on sort de la boucle
					exitLoop = true;
				}
			} else if (reader.getEventType() == XMLStreamReader.START_ELEMENT) {
				if (reader.getLocalName().equalsIgnoreCase("element")) {
					// memorise la valeur de l'attribut name de chaque element
					String attributeName = new String();
					// memorise la valeur de l'attribut type de chaque element
					String attributeType = new String();
					for (int i = 0; i < reader.getAttributeCount(); i++) {
						if (reader.getAttributeLocalName(i).equalsIgnoreCase(
								"name")) {
							attributeName = new String(reader
									.getAttributeValue(i));
						} else if (reader.getAttributeLocalName(i)
								.equalsIgnoreCase("type")) {
							attributeType = new String(reader
									.getAttributeValue(i));
						}
					}
					// si attributeType contient "gml" c'est qu'il s'agit de la
					// geometry et nom d'un attribut. il ne faut donc pas
					// l'ajouter a la liste
					if (!attributeType.contains("gml")) {
						listeAttributes.put(attributeName, attributeType
								.substring(attributeType.indexOf(":") + 1));
					} else {
						geometryDelimiter = new String(attributeName);
					}
				}
			}
			reader.next();
		}
		return listeAttributes;
	}

	/**
	 * Pour faire des tests
	 * 
	 * @param args
	 * @throws XMLStreamException
	 */
	public static void main(String[] args) throws XMLStreamException {
		ReadSchema schema = new ReadSchema();
		schema.readSchema("../datas2tests/gml/surface/eau.xsd");
	}
}