#ifndef LIBECWJ2
#  define LIBECWJ2
#  define LINUX
#  define _LARGEFILE_SOURCE
#  define _LARGEFILE64_SOURCE
#  define _FILE_OFFSET_BITS=64
#  define POSIX
#endif
