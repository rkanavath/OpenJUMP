#!/bin/sh

# Contributor: Homme Zwaagstra, danitool
pkgname=libecwj2
pkgver=3.3


srcdir=$(dirname $0)

  # Memory leak patches from http://trac.osgeo.org/mapserver/ticket/3245
  patch -f -p0 -i ${srcdir}/libecwj2-3.3-3245a.patch
  patch -f -p0 -i ${srcdir}/libecwj2-3.3-3245b.patch

  # Memory overflow patch from http://trac.osgeo.org/gdal/ticket/3366
  patch -f -p0 -i ${srcdir}/libecwj2-3.3-NCSPhysicalMemorySize-Linux.patch

  # Fix crash creating 16bit JP images on x86_64 from http://trac.osgeo.org/gdal/ticket/2593
  patch -f -p0 -i ${srcdir}/libecwj2-3.3-2593.patch

  ## Gentoo patch
  #patch -Np 0 -i "$srcdir/${pkgname}-${pkgver}-nolcms.patch" || return 1
  #rm -rf Source/C/libjpeg Source/C/NCSEcw/lcms

  ## Gentoo bug 328075
  #sed -i -e "s:includeHEADERS_INSTALL:INSTALL_HEADER:" \
  #    Source/NCSBuildGnu/Makefile.am || return 1

  # std::length_error bug
  patch -f -p0 -i ${srcdir}/libecwj2-3.3-wcharfix.patch
